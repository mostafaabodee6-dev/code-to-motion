# CODE TO MOTION: مشروع الورشة

مشروع Remotion كامل لورشة **CODE TO MOTION**. تقديم: عبدالرحمن مصطفى.
فيه كل درس من الورشة جاهز، ومعه فيديو الافتتاح والمشروع النهائي وقالب التحدي.

## التشغيل

```bash
npm install      # مرة وحدة بس، تنزّل المكتبات
npm run dev      # يفتح Remotion Studio في المتصفح
```

> على Windows، لو PowerShell منع تشغيل الأوامر، استخدم `npm.cmd` و `npx.cmd` بدل `npm` و `npx`.

## محتوى المشروع

| في Studio | الملف | ايش يعلّم |
|---|---|---|
| `Intro` | `src/intro/Intro.tsx` | فيديو افتتاح الورشة (29 ثانية) بصوتك |
| `L01-FirstAnimation` | `src/lessons/L01_FirstAnimation.tsx` | `useCurrentFrame`: الفريم هو اللي يحرّك كل شي |
| `L02-Interpolate` | `src/lessons/L02_Interpolate.tsx` | `interpolate`: ظهور ودخول وتكبير، و `clamp` و `Easing` |
| `L03-Spring` | `src/lessons/L03_Spring.tsx` | `spring` وتأثير رقم `damping` |
| `L04-Sequence` | `src/lessons/L04_Sequence.tsx` | تقسيم الفيديو لمشاهد بـ `Sequence` |
| `L05-Transitions` | `src/lessons/L05_Transitions.tsx` | انتقالات `fade` و `slide` و `wipe` |
| `L06-Media` | `src/lessons/L06_Media.tsx` | الصور والخط والصوت من مجلد `public` |
| `FinalProject` | `src/final/` | المشروع النهائي: فيديو 12 ثانية من 4 مشاهد |
| `AboutMe` | `src/challenge/AboutMe.tsx` | قالب التحدي: فيديو 10 ثواني عن نفسك |
| `Templates/T01…T08` | `src/templates/` | 8 قوالب جاهزة: About Me، Logo Reveal، Lower Third، App Promo، Social Reel (عمودي)، Explainer، Countdown، Stats |
| `Live/SpeakerIntro` | `src/live/SpeakerIntro.tsx` | تعريف المقدّم 25 ثانية (60fps) |
| `Live/QnALoop` | `src/live/QnALoop.tsx` | شاشة الأسئلة 20 ثانية، loop بدون قفزة (للـ OBS) |
| `Live/Closing` | `src/live/Closing.tsx` | شاشة الختام 30 ثانية مع QR لموقع الورشة |

ملفات مشتركة:
- `src/theme.ts`: الألوان والخط. غيّرها هنا وتتغيّر في كل الفيديوهات.
- `src/components/Background.tsx`: الخلفية المتدرجة المتحركة.
- `src/components/Words.tsx`: نص يظهر كلمة كلمة (Kinetic Typography).
- `public/`: الشعار والخطوط والمؤثرات الصوتية.

## تغيير النصوص بدون كود

في `FinalProject` و `AboutMe` افتح لوحة **Props** على يمين Studio، وغيّر النص أو اللون، وتشوف النتيجة مباشرة.

## التصدير (Render)

```bash
npx remotion render FinalProject out/final.mp4
npx remotion render Intro out/intro.mp4
npx remotion render AboutMe out/about-me.mp4
npx remotion render QnALoop out/qna-loop.mp4 --muted
```

يطلع الفيديو MP4 داخل مجلد `out`.

## القوالب

كل قالب تغيّر نصوصه وألوانه من لوحة **Props** بدون كود.
- `T03-LowerThird` شفاف: علّم `showBackdrop` على false، وصدّره بخلفية شفافة:
  `npx remotion render T03-LowerThird out/lower-third.mov --codec=prores --prores-profile=4444 --pixel-format=yuva444p10le --image-format=png`
- `T07-Countdown`: غيّر `seconds` وتتغير مدة الفيديو تلقائيًا.
- `T04-AppPromo`: حط صورة شاشة تطبيقك في `public/templates/` واكتب اسمها في `screenshot`.

## التحدي 🏆

1. افتح `AboutMe` في Studio.
2. اكتب اسمك ووصفك و3 مهارات، واختار لونك.
3. صدّر الفيديو، وشاركه مع منشن لـ `@mostafaabodee8`.

## روابط

- توثيق Remotion: https://www.remotion.dev/docs
- الانتقالات: https://www.remotion.dev/docs/transitions
- مؤثرات صوتية مجانية: https://pixabay.com/sound-effects/
