// الدرس 6 — الصور والخطوط والصوت
// 1) أي ملف تحطه في مجلد public تستدعيه بـ staticFile('اسم الملف')
// 2) الصور: <Img>   الصوت: <Audio>   الفيديو: <OffthreadVideo>
// 3) الصوت داخل Sequence يبدأ في الفريم اللي تحدده

import React from 'react';
import {AbsoluteFill, Audio, Img, interpolate, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Background} from '../components/Background';
import {Label} from '../components/Label';
import {COLORS, FONT} from '../theme';

export const L06_Media: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const logoIn = spring({frame: frame - 10, fps, config: {damping: 10}});
  const textIn = spring({frame: frame - 35, fps, config: {damping: 200}});

  return (
    <AbsoluteFill>
      <Background />
      <Label text="الدرس 6 · صور وخطوط وصوت" />

      {/* موسيقى خلفية بصوت منخفض (volume من 0 إلى 1) */}
      <Audio src={staticFile('sfx/music.wav')} volume={(f) => interpolate(f, [0, 20], [0, 0.35], {extrapolateRight: 'clamp'})} />

      {/* مؤثر "بوب" مع ظهور الشعار في الفريم 10 */}
      <Sequence from={10}>
        <Audio src={staticFile('sfx/pop.wav')} />
      </Sequence>

      {/* مؤثر "ووش" مع دخول النص في الفريم 35 */}
      <Sequence from={32}>
        <Audio src={staticFile('sfx/whoosh.wav')} volume={0.7} />
      </Sequence>

      <AbsoluteFill style={{flexDirection: 'row-reverse', justifyContent: 'center', alignItems: 'center', gap: 90}}>
        <Img
          src={staticFile('logo.png')}
          style={{width: 460, height: 460, borderRadius: 70, transform: `scale(${logoIn}) rotate(${(1 - logoIn) * -20}deg)`}}
        />
        <div style={{direction: 'rtl', opacity: textIn, transform: `translateX(${(1 - textIn) * -80}px)`}}>
          <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 110, color: COLORS.white, lineHeight: 1.2}}>عبدالرحمن مصطفى</div>
          <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 56, color: COLORS.cyan}}>مصمم جرافيك ومونتير</div>
          <div style={{fontFamily: FONT, fontWeight: 400, fontSize: 40, color: COLORS.muted, marginTop: 20}}>خط Cairo من مجلد public/fonts</div>
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
