// الدرس 4 — Sequence
// Sequence تقسّم الفيديو لمشاهد.
// from = متى يبدأ المشهد، durationInFrames = كم يطوّل.
// أهم نقطة: داخل كل Sequence، العدّ يبدأ من صفر من جديد!

import React from 'react';
import {AbsoluteFill, interpolate, Sequence, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {Background} from '../components/Background';
import {Label} from '../components/Label';
import {COLORS, FONT} from '../theme';

const Scene: React.FC<{title: string; color: string}> = ({title, color}) => {
  const frame = useCurrentFrame(); // ← يبدأ من 0 داخل كل مشهد
  const {fps} = useVideoConfig();
  const enter = spring({frame, fps, config: {damping: 14}});
  const opacity = interpolate(frame, [0, 10], [0, 1], {extrapolateRight: 'clamp'});

  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', gap: 30}}>
      <div
        style={{
          fontFamily: FONT,
          fontWeight: 900,
          fontSize: 170,
          color,
          opacity,
          transform: `translateY(${(1 - enter) * 120}px)`,
        }}
      >
        {title}
      </div>
      <div style={{fontFamily: 'monospace', fontSize: 48, color: COLORS.white}}>frame داخل المشهد = {frame}</div>
    </AbsoluteFill>
  );
};

export const L04_Sequence: React.FC = () => (
  <AbsoluteFill>
    <Background colors={[COLORS.blue, COLORS.pink, COLORS.violet]} />
    <Label text="الدرس 4 · Sequence" />

    <Sequence from={0} durationInFrames={60}>
      <Scene title="المشهد الأول" color={COLORS.cyan} />
    </Sequence>

    <Sequence from={60} durationInFrames={60}>
      <Scene title="المشهد الثاني" color={COLORS.yellow} />
    </Sequence>

    <Sequence from={120}>
      <Scene title="المشهد الثالث" color={COLORS.pink} />
    </Sequence>
  </AbsoluteFill>
);
