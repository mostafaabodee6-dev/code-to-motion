// الدرس 3 — spring
// spring تعطيك حركة طبيعية فيها "نطّة" زي الواقع.
// damping = قوة التهدئة: رقم صغير = نطّ أكثر، رقم كبير = حركة هادية بدون نطّ.

import React from 'react';
import {AbsoluteFill, Img, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Background} from '../components/Background';
import {Label} from '../components/Label';
import {COLORS, FONT} from '../theme';

const Logo: React.FC<{damping: number; delay: number; color: string}> = ({damping, delay, color}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const scale = spring({frame: frame - delay, fps, config: {damping}});

  return (
    <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 40}}>
      <Img
        src={staticFile('logo.png')}
        style={{
          width: 340,
          height: 340,
          borderRadius: 60,
          transform: `scale(${scale})`,
          border: `6px solid ${color}`,
          boxShadow: `0 0 80px ${color}88`,
        }}
      />
      <div style={{fontFamily: 'monospace', fontSize: 48, color}}>damping: {damping}</div>
    </div>
  );
};

export const L03_Spring: React.FC = () => (
  <AbsoluteFill>
    <Background colors={[COLORS.orange, COLORS.violet, COLORS.pink]} />
    <Label text="الدرس 3 · spring" />
    <AbsoluteFill style={{flexDirection: 'row-reverse', justifyContent: 'center', alignItems: 'center', gap: 120}}>
      <Logo damping={4} delay={0} color={COLORS.yellow} />
      <Logo damping={12} delay={10} color={COLORS.cyan} />
      <Logo damping={200} delay={20} color={COLORS.white} />
    </AbsoluteFill>
    <div
      style={{position: 'absolute', bottom: 70, width: '100%', textAlign: 'center', fontFamily: FONT, fontSize: 40, color: COLORS.muted, direction: 'rtl'}}
    >
      نفس الحركة… بس رقم damping مختلف
    </div>
  </AbsoluteFill>
);
