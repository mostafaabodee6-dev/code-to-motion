// الدرس 1 — أول حركة: useCurrentFrame
// الفكرة كلها: الفيديو = صور ورا بعض (frames).
// useCurrentFrame() يعطيك رقم الصورة الحالية: 0، 1، 2، 3 ...
// وأنت تحسب منه شكل كل شي في الشاشة.

import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Background} from '../components/Background';
import {Label} from '../components/Label';
import {COLORS, FONT} from '../theme';

export const L01_FirstAnimation: React.FC = () => {
  const frame = useCurrentFrame();

  // الشفافية تزيد مع الوقت: من 0 إلى 1 خلال 30 فريم (ثانية وحدة)
  const opacity = Math.min(1, frame / 30);

  // النص ينزل من فوق شوي شوي (يتوقف عند 0)
  const y = Math.max(0, 60 - frame * 2);

  return (
    <AbsoluteFill>
      <Background />
      <Label text="الدرس 1 · useCurrentFrame" />

      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
        <h1
          style={{
            fontFamily: FONT,
            fontWeight: 900,
            fontSize: 140,
            color: COLORS.white,
            opacity,
            transform: `translateY(${y}px)`,
            margin: 0,
            direction: 'rtl',
          }}
        >
          أهلًا بـ Remotion
        </h1>
      </AbsoluteFill>

      {/* عدّاد الفريم — عشان الحضور يشوفون الرقم يتغيّر */}
      <div
        style={{
          position: 'absolute',
          bottom: 70,
          left: 80,
          fontFamily: 'monospace',
          fontSize: 44,
          color: COLORS.cyan,
          background: 'rgba(0,0,0,0.35)',
          padding: '12px 28px',
          borderRadius: 16,
        }}
      >
        frame = {frame}
      </div>
    </AbsoluteFill>
  );
};
