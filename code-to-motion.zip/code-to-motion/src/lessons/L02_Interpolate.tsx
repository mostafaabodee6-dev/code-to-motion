// الدرس 2 — interpolate
// interpolate تحوّل رقم الفريم لأي قيمة تبغاها.
// interpolate(frame, [من فريم, إلى فريم], [من قيمة, إلى قيمة])
// extrapolateRight: 'clamp' = لا تكمّل بعد آخر قيمة (توقّف عندها)

import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {Background} from '../components/Background';
import {Label} from '../components/Label';
import {COLORS, FONT} from '../theme';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const Card: React.FC<{title: string; color: string; style: React.CSSProperties}> = ({title, color, style}) => (
  <div
    style={{
      width: 420,
      height: 420,
      borderRadius: 48,
      background: color,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: FONT,
      fontWeight: 900,
      fontSize: 64,
      color: COLORS.bg,
      boxShadow: '0 30px 80px rgba(0,0,0,0.35)',
      ...style,
    }}
  >
    {title}
  </div>
);

export const L02_Interpolate: React.FC = () => {
  const frame = useCurrentFrame();

  // 1) ظهور تدريجي: الشفافية من 0 إلى 1 بين الفريم 0 و 30
  const opacity = interpolate(frame, [0, 30], [0, 1], clamp);

  // 2) دخول من اليمين مع Easing (يبطّئ في النهاية)
  const x = interpolate(frame, [20, 50], [600, 0], {...clamp, easing: Easing.out(Easing.cubic)});

  // 3) تكبير: من نصف الحجم للحجم الكامل
  const scale = interpolate(frame, [40, 70], [0.4, 1], clamp);

  // 🔴 جرّب تشيل clamp من السطر اللي فوق — بتشوف الكرت يكبر بلا نهاية!

  return (
    <AbsoluteFill>
      <Background colors={[COLORS.cyan, COLORS.violet, COLORS.pink]} />
      <Label text="الدرس 2 · interpolate" />
      <AbsoluteFill style={{flexDirection: 'row-reverse', justifyContent: 'center', alignItems: 'center', gap: 80}}>
        <Card title="ظهور" color={COLORS.cyan} style={{opacity}} />
        <Card title="دخول" color={COLORS.yellow} style={{transform: `translateX(${x}px)`}} />
        <Card title="تكبير" color={COLORS.pink} style={{transform: `scale(${scale})`}} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
