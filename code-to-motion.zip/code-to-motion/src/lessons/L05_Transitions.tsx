// الدرس 5 — الانتقالات بين المشاهد
// TransitionSeries تشغّل المشاهد ورا بعض، وبينها انتقال (fade أو slide أو wipe ...)
// الحزمة: @remotion/transitions

import React from 'react';
import {AbsoluteFill} from 'remotion';
import {linearTiming, springTiming, TransitionSeries} from '@remotion/transitions';
import {fade} from '@remotion/transitions/fade';
import {slide} from '@remotion/transitions/slide';
import {wipe} from '@remotion/transitions/wipe';
import {Label} from '../components/Label';
import {COLORS, FONT} from '../theme';

const Panel: React.FC<{text: string; bg: string; color?: string}> = ({text, bg, color = COLORS.white}) => (
  <AbsoluteFill style={{background: bg, justifyContent: 'center', alignItems: 'center'}}>
    <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 180, color}}>{text}</div>
  </AbsoluteFill>
);

export const L05_Transitions: React.FC = () => (
  <AbsoluteFill>
    <TransitionSeries>
      <TransitionSeries.Sequence durationInFrames={50}>
        <Panel text="فكرة" bg={`linear-gradient(135deg, ${COLORS.violet}, ${COLORS.pink})`} />
      </TransitionSeries.Sequence>

      {/* انتقال 1: تلاشي fade */}
      <TransitionSeries.Transition presentation={fade()} timing={linearTiming({durationInFrames: 15})} />

      <TransitionSeries.Sequence durationInFrames={50}>
        <Panel text="كود" bg={`linear-gradient(135deg, ${COLORS.blue}, ${COLORS.cyan})`} />
      </TransitionSeries.Sequence>

      {/* انتقال 2: سحب slide بحركة spring */}
      <TransitionSeries.Transition presentation={slide({direction: 'from-right'})} timing={springTiming({config: {damping: 200}, durationInFrames: 20})} />

      <TransitionSeries.Sequence durationInFrames={50}>
        <Panel text="حركة" bg={`linear-gradient(135deg, ${COLORS.orange}, ${COLORS.pink})`} />
      </TransitionSeries.Sequence>

      {/* انتقال 3: مسح wipe */}
      <TransitionSeries.Transition presentation={wipe({direction: 'from-top-right'})} timing={linearTiming({durationInFrames: 20})} />

      <TransitionSeries.Sequence durationInFrames={60}>
        <Panel text="فيديو" bg={COLORS.yellow} color={COLORS.bg} />
      </TransitionSeries.Sequence>
    </TransitionSeries>
    <Label text="الدرس 5 · Transitions" />
  </AbsoluteFill>
);
