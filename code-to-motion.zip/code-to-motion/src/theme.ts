// ألوان وخطوط الورشة — غيّرها مرة وحدة هنا وتتغيّر في كل الفيديوهات
import {loadFont} from '@remotion/fonts';
import {staticFile} from 'remotion';

export const COLORS = {
  bg: '#14063F',
  violet: '#7B2CFF',
  pink: '#FF2E9A',
  blue: '#2F6BFF',
  cyan: '#4FF0FF',
  yellow: '#FFD84D',
  orange: '#FF8A3D',
  white: '#FFFFFF',
  muted: '#D3CAF2',
};

// خط Cairo محفوظ داخل مجلد public/fonts — يشتغل بدون إنترنت
export const FONT = 'Cairo';
for (const weight of ['400', '700', '900']) {
  loadFont({family: FONT, url: staticFile(`fonts/Cairo-${weight}.ttf`), weight});
}

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
