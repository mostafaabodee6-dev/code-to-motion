// مشاهد المشروع النهائي (4 مشاهد)
import React from 'react';
import {AbsoluteFill, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Background} from '../components/Background';
import {Words} from '../components/Words';
import {COLORS, FONT} from '../theme';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// ───────── المشهد 1: الفكرة (Hook) ─────────
export const SceneHook: React.FC<{text: string; accent: string}> = ({text, accent}) => {
  const frame = useCurrentFrame();
  const glow = interpolate(frame, [20, 60], [0, 1], clamp);
  return (
    <AbsoluteFill>
      <Background />
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
        <div
          style={{
            position: 'absolute',
            width: 520,
            height: 520,
            borderRadius: '50%',
            background: `radial-gradient(circle, ${accent}55, transparent 70%)`,
            opacity: glow,
            transform: `scale(${0.6 + glow * 0.6})`,
          }}
        />
        <Words text={text} size={130} highlight={{word: 'فكرة', color: accent}} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

// ───────── المشهد 2: المشكلة ─────────
const TOOLS = ['مونتاج', 'تصميم', 'صوت', 'ترجمة', 'تصدير', 'نشر'];

export const SceneProblem: React.FC<{text: string}> = ({text}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <AbsoluteFill>
      <Background colors={[COLORS.orange, COLORS.pink, COLORS.violet]} />
      {TOOLS.map((t, i) => {
        const p = spring({frame: frame - i * 4, fps, config: {damping: 9}});
        const angle = (i / TOOLS.length) * Math.PI * 2 + Math.PI / 6; // نبعدها عن مكان النص
        const r = 520 * p;
        const wobble = Math.sin((frame + i * 10) / 6) * 6;
        return (
          <div
            key={t}
            style={{
              position: 'absolute',
              left: 960 + Math.cos(angle) * r * 1.35 - 150,
              top: 540 + Math.sin(angle) * r * 0.75 - 55,
              width: 300,
              height: 110,
              borderRadius: 28,
              background: 'rgba(20,6,63,0.75)',
              border: '2px solid rgba(255,255,255,0.3)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontFamily: FONT,
              fontWeight: 700,
              fontSize: 48,
              color: COLORS.white,
              transform: `rotate(${wobble}deg)`,
              opacity: p,
            }}
          >
            {t}
          </div>
        );
      })}
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
        <Words text={text} start={12} size={110} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

// ───────── المشهد 3: الحل ─────────
const CODE = `const frame = useCurrentFrame();
const scale = spring({frame, fps});
return <Title style={{scale}} />;`;

export const SceneSolution: React.FC<{text: string; accent: string}> = ({text, accent}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const chars = Math.floor(interpolate(frame, [15, 75], [0, CODE.length], clamp));
  const arrow = interpolate(frame, [70, 85], [0, 1], clamp);
  const play = spring({frame: frame - 82, fps, config: {damping: 10}});
  const bar = interpolate(frame, [90, 135], [0, 100], clamp);

  return (
    <AbsoluteFill>
      <Background colors={[COLORS.cyan, COLORS.blue, COLORS.violet]} />
      <div style={{position: 'absolute', top: 110, width: '100%', display: 'flex', justifyContent: 'center'}}>
        <Words text={text} size={92} highlight={{word: 'كود', color: accent}} />
      </div>

      {/* نافذة الكود */}
      <div
        style={{
          position: 'absolute',
          left: 150,
          top: 400,
          width: 860,
          height: 430,
          borderRadius: 28,
          background: '#0b0720',
          border: '2px solid rgba(255,255,255,0.15)',
          padding: '70px 44px',
          boxSizing: 'border-box',
          fontFamily: 'monospace',
          fontSize: 38,
          lineHeight: 1.7,
          color: COLORS.cyan,
          whiteSpace: 'pre',
          direction: 'ltr',
        }}
      >
        <div style={{position: 'absolute', top: 24, left: 30, display: 'flex', gap: 12}}>
          {['#ff5f57', '#febc2e', '#28c840'].map((c) => (
            <div key={c} style={{width: 18, height: 18, borderRadius: 9, background: c}} />
          ))}
        </div>
        {CODE.slice(0, chars)}
        <span style={{opacity: frame % 20 < 10 ? 1 : 0}}>▍</span>
      </div>

      {/* السهم */}
      <div style={{position: 'absolute', left: 1040, top: 585, width: 120 * arrow, height: 10, borderRadius: 5, background: accent}} />

      {/* إطار الفيديو */}
      <div
        style={{
          position: 'absolute',
          left: 1190,
          top: 420,
          width: 580,
          height: 390,
          borderRadius: 28,
          background: `linear-gradient(135deg, ${COLORS.violet}, ${COLORS.pink})`,
          transform: `scale(${play})`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          overflow: 'hidden',
        }}
      >
        <div
          style={{
            width: 0,
            height: 0,
            borderTop: '55px solid transparent',
            borderBottom: '55px solid transparent',
            borderLeft: `90px solid ${COLORS.white}`,
            marginLeft: 20,
          }}
        />
        <div style={{position: 'absolute', bottom: 30, left: 30, right: 30, height: 12, borderRadius: 6, background: 'rgba(255,255,255,0.3)'}}>
          <div style={{width: `${bar}%`, height: '100%', borderRadius: 6, background: COLORS.white}} />
        </div>
      </div>
    </AbsoluteFill>
  );
};

// ───────── المشهد 4: كشف الشعار ─────────
export const SceneReveal: React.FC<{title: string; tagline: string; presenter: string; accent: string}> = ({title, tagline, presenter, accent}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const logo = spring({frame: frame - 5, fps, config: {damping: 11}});
  const ring = interpolate(frame, [5, 45], [0, 1], clamp);
  const sub = spring({frame: frame - 35, fps, config: {damping: 200}});
  const name = interpolate(frame, [55, 75], [0, 1], clamp);

  return (
    <AbsoluteFill>
      <Background colors={[COLORS.pink, COLORS.blue, COLORS.violet]} />
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'column'}}>
        <div
          style={{
            position: 'absolute',
            top: 140,
            width: 300,
            height: 300,
            borderRadius: '50%',
            border: `4px solid ${accent}`,
            opacity: 1 - ring,
            transform: `scale(${0.8 + ring * 1.6})`,
          }}
        />
        <Img src={staticFile('logo.png')} style={{width: 230, height: 230, borderRadius: 46, transform: `scale(${logo})`, marginBottom: 40}} />
        <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 150, color: COLORS.white, letterSpacing: 4, direction: 'ltr', transform: `scale(${0.8 + logo * 0.2})`, opacity: logo}}>
          {title}
        </div>
        <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 56, color: accent, direction: 'rtl', opacity: sub, transform: `translateY(${(1 - sub) * 40}px)`}}>
          {tagline}
        </div>
        <div style={{fontFamily: FONT, fontWeight: 400, fontSize: 40, color: COLORS.muted, marginTop: 30, direction: 'rtl', opacity: name}}>
          {presenter}
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
