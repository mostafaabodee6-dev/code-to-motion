// المشروع النهائي — فيديو 12 ثانية من 4 مشاهد
// يجمع كل اللي تعلمناه: interpolate + spring + Sequence + Transitions + صوت
// غيّر النصوص واللون من لوحة Props في Remotion Studio (يمين الشاشة)

import React from 'react';
import {AbsoluteFill, Audio, interpolate, Sequence, staticFile} from 'remotion';
import {linearTiming, TransitionSeries} from '@remotion/transitions';
import {fade} from '@remotion/transitions/fade';
import {slide} from '@remotion/transitions/slide';
import {wipe} from '@remotion/transitions/wipe';
import {FinalProps} from './schema';
import {SceneHook, SceneProblem, SceneReveal, SceneSolution} from './Scenes';

const T = 20; // مدة كل انتقال بالفريمات

// المدة الكلية = مجموع المشاهد − مجموع الانتقالات
// 75 + 105 + 135 + 105 − (3 × 20) = 360 فريم = 12 ثانية
export const FINAL_DURATION = 75 + 105 + 135 + 105 - 3 * T;

export const FinalProject: React.FC<FinalProps> = ({hook, problem, solution, title, tagline, presenter, accent}) => (
  <AbsoluteFill>
    <TransitionSeries>
      <TransitionSeries.Sequence durationInFrames={75}>
        <SceneHook text={hook} accent={accent} />
      </TransitionSeries.Sequence>
      <TransitionSeries.Transition presentation={slide({direction: 'from-left'})} timing={linearTiming({durationInFrames: T})} />

      <TransitionSeries.Sequence durationInFrames={105}>
        <SceneProblem text={problem} />
      </TransitionSeries.Sequence>
      <TransitionSeries.Transition presentation={wipe({direction: 'from-right'})} timing={linearTiming({durationInFrames: T})} />

      <TransitionSeries.Sequence durationInFrames={135}>
        <SceneSolution text={solution} accent={accent} />
      </TransitionSeries.Sequence>
      <TransitionSeries.Transition presentation={fade()} timing={linearTiming({durationInFrames: T})} />

      <TransitionSeries.Sequence durationInFrames={105}>
        <SceneReveal title={title} tagline={tagline} presenter={presenter} accent={accent} />
      </TransitionSeries.Sequence>
    </TransitionSeries>

    {/* ───── الصوت ───── */}
    <Audio
      src={staticFile('sfx/music.wav')}
      volume={(f) => interpolate(f, [0, 15, FINAL_DURATION - 30, FINAL_DURATION], [0, 0.4, 0.4, 0], {extrapolateRight: 'clamp'})}
    />
    {/* "ووش" مع كل انتقال: يبدأ الانتقال عند نهاية المشهد ناقص T */}
    {[75 - T, 75 + 105 - 2 * T, 75 + 105 + 135 - 3 * T].map((f) => (
      <Sequence key={f} from={f - 3} durationInFrames={25}>
        <Audio src={staticFile('sfx/whoosh.wav')} volume={0.6} />
      </Sequence>
    ))}
    {/* ضربة قوية مع ظهور الشعار */}
    <Sequence from={75 + 105 + 135 - 3 * T + 5}>
      <Audio src={staticFile('sfx/hit.wav')} volume={0.8} />
    </Sequence>
  </AbsoluteFill>
);
