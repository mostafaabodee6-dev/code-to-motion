// خصائص الفيديو اللي تقدر تغيّرها من Remotion Studio بدون ما تلمس الكود
import {z} from 'zod';
import {zColor} from '@remotion/zod-types';

export const finalSchema = z.object({
  hook: z.string(),
  problem: z.string(),
  solution: z.string(),
  title: z.string(),
  tagline: z.string(),
  presenter: z.string(),
  accent: zColor(),
});

export type FinalProps = z.infer<typeof finalSchema>;
