// قالب 02 — كشف الشعار (5 ثواني): دوائر تنفجر، الشعار ينط، والاسم يدخل
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {z} from 'zod';
import {zColor} from '@remotion/zod-types';
import {useIn, Txt} from './kit';

export const logoRevealSchema = z.object({
  logo: z.string(), // اسم ملف داخل public
  brand: z.string(),
  tagline: z.string(),
  bg: zColor(),
  accent: zColor(),
});
export const LOGO_REVEAL_DURATION = 150;

export const LogoReveal: React.FC<z.infer<typeof logoRevealSchema>> = ({logo, brand, tagline, bg, accent}) => {
  const frame = useCurrentFrame();
  const logoIn = useIn(18, 9);
  const nameIn = useIn(45);
  const tagIn = useIn(62);
  const glow = interpolate(frame, [18, 60], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{background: `radial-gradient(circle at 50% 45%, ${accent}${Math.round(glow * 60).toString(16).padStart(2, '0')}, ${bg} 60%)`, justifyContent: 'center', alignItems: 'center'}}>
      {[0, 1, 2].map((k) => {
        const p = interpolate(frame, [8 + k * 6, 50 + k * 6], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
        return <div key={k} style={{position: 'absolute', top: '42%', left: '50%', width: 200 + p * 1400, height: 200 + p * 1400, marginLeft: -(100 + p * 700), marginTop: -(100 + p * 700), borderRadius: '50%', border: `4px solid ${accent}`, opacity: (1 - p) * 0.7}} />;
      })}
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 26}}>
        <Img src={staticFile(logo)} style={{width: 260, height: 260, objectFit: 'cover', borderRadius: 60, transform: `scale(${logoIn}) rotate(${(1 - logoIn) * -90}deg)`, boxShadow: `0 0 ${glow * 90}px ${accent}`}} />
        <Txt size={110} style={{opacity: nameIn, transform: `translateY(${(1 - nameIn) * 40}px)`, letterSpacing: 4}}>{brand}</Txt>
        <Txt size={44} weight={700} color={accent} style={{opacity: tagIn}}>{tagline}</Txt>
      </div>
      <Sequence from={14}><Audio src={staticFile('sfx/hit.wav')} volume={0.6} /></Sequence>
    </AbsoluteFill>
  );
};
