// قالب 06 — فيديو شرح (20 ثانية): سؤال، ثم 3 خطوات بأيقونات أرقام، ثم الخلاصة
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {TransitionSeries, linearTiming} from '@remotion/transitions';
import {fade} from '@remotion/transitions/fade';
import {slide} from '@remotion/transitions/slide';
import {z} from 'zod';
import {zColor} from '@remotion/zod-types';
import {Background} from '../components/Background';
import {useIn, Txt} from './kit';

export const explainerSchema = z.object({
  question: z.string(),
  steps: z.array(z.object({title: z.string(), text: z.string()})).length(3),
  summary: z.string(),
  accent: zColor(),
});
// 5 مشاهد × 132 − 4 انتقالات × 15 = 600
export const EXPLAINER_DURATION = 600;

const Center: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', padding: 140}}><Background /><div style={{position: 'relative'}}>{children}</div></AbsoluteFill>
);
const Step: React.FC<{i: number; title: string; text: string; accent: string}> = ({i, title, text, accent}) => {
  const p = useIn(8, 12); const q = useIn(22);
  return (
    <Center>
      <div style={{display: 'flex', alignItems: 'center', gap: 80, direction: 'rtl'}}>
        <div style={{width: 300, height: 300, borderRadius: 80, background: accent, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Cairo', fontWeight: 900, fontSize: 200, color: '#14063F', transform: `scale(${p}) rotate(${(1 - p) * 30}deg)`}}>{i}</div>
        <div style={{maxWidth: 1000}}>
          <Txt size={96} style={{opacity: p}}>{title}</Txt>
          <Txt size={50} weight={400} color="#D3CAF2" style={{opacity: q, transform: `translateY(${(1 - q) * 30}px)`}}>{text}</Txt>
        </div>
      </div>
    </Center>
  );
};
const Big: React.FC<{text: string; color?: string}> = ({text, color}) => {
  const p = useIn(6);
  return <Center><Txt size={110} color={color} style={{textAlign: 'center', opacity: p, transform: `scale(${0.85 + p * 0.15})`}}>{text}</Txt></Center>;
};

export const Explainer: React.FC<z.infer<typeof explainerSchema>> = ({question, steps, summary, accent}) => {
  const t = linearTiming({durationInFrames: 15});
  return (
    <TransitionSeries>
      <TransitionSeries.Sequence durationInFrames={132}><Big text={question} /></TransitionSeries.Sequence>
      {steps.map((s, i) => (
        <React.Fragment key={i}>
          <TransitionSeries.Transition presentation={i === 0 ? fade() : slide({direction: 'from-left'})} timing={t} />
          <TransitionSeries.Sequence durationInFrames={132}><Step i={i + 1} title={s.title} text={s.text} accent={accent} /></TransitionSeries.Sequence>
        </React.Fragment>
      ))}
      <TransitionSeries.Transition presentation={fade()} timing={t} />
      <TransitionSeries.Sequence durationInFrames={132}><Big text={summary} color={accent} /></TransitionSeries.Sequence>
    </TransitionSeries>
  );
};
