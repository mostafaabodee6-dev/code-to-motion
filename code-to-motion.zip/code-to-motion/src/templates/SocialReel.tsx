// قالب 05 — ريل عمودي 1080×1920 (15 ثانية): هوك، 3 نقاط، ونهاية فيها حسابك
import React from 'react';
import {AbsoluteFill, Series} from 'remotion';
import {z} from 'zod';
import {zColor} from '@remotion/zod-types';
import {Background} from '../components/Background';
import {Words} from '../components/Words';
import {useIn, Txt} from './kit';

export const socialReelSchema = z.object({
  hook: z.string(),
  points: z.array(z.string()).length(3),
  handle: z.string(),
  accent: zColor(),
});
export const SOCIAL_REEL_DURATION = 450;

const Point: React.FC<{n: number; text: string; accent: string}> = ({n, text, accent}) => {
  const p = useIn(0, 11);
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', padding: 90}}>
      <div style={{fontFamily: 'Cairo', fontWeight: 900, fontSize: 340, color: accent, lineHeight: 1, transform: `scale(${p})`}}>{n}</div>
      <Txt size={88} style={{textAlign: 'center', opacity: p, transform: `translateY(${(1 - p) * 60}px)`}}>{text}</Txt>
    </AbsoluteFill>
  );
};
const End: React.FC<{handle: string; accent: string}> = ({handle, accent}) => {
  const p = useIn(0, 10);
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', gap: 30}}>
      <Txt size={80}>تابعني لأكثر</Txt>
      <div style={{fontFamily: 'Cairo', fontWeight: 900, fontSize: 84, color: '#14063F', background: accent, borderRadius: 999, padding: '14px 56px', transform: `scale(${p})`, direction: 'ltr'}}>{handle}</div>
    </AbsoluteFill>
  );
};

export const SocialReel: React.FC<z.infer<typeof socialReelSchema>> = ({hook, points, handle, accent}) => (
  <AbsoluteFill>
    <Background />
    <Series>
      <Series.Sequence durationInFrames={90}>
        <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', padding: 80}}><Words text={hook} size={120} highlight={{word: hook.split(' ').slice(-1)[0], color: accent}} /></AbsoluteFill>
      </Series.Sequence>
      {points.map((pt, i) => (
        <Series.Sequence key={i} durationInFrames={90}><Point n={i + 1} text={pt} accent={accent} /></Series.Sequence>
      ))}
      <Series.Sequence durationInFrames={90}><End handle={handle} accent={accent} /></Series.Sequence>
    </Series>
  </AbsoluteFill>
);
