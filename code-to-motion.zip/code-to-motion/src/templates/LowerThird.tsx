// قالب 03 — شريط تعريفي (Lower Third) بخلفية شفافة: صدّره ProRes أو WebM وحطه فوق أي فيديو
import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {z} from 'zod';
import {zColor} from '@remotion/zod-types';
import {useIn, useOut, Txt} from './kit';

export const lowerThirdSchema = z.object({
  name: z.string(),
  title: z.string(),
  accent: zColor(),
  showBackdrop: z.boolean(), // للمعاينة بس: خلفية رمادية عشان تشوف الشريط
});
export const LOWER_THIRD_DURATION = 180;

export const LowerThird: React.FC<z.infer<typeof lowerThirdSchema>> = ({name, title, accent, showBackdrop}) => {
  const frame = useCurrentFrame();
  const bar = useIn(0, 16);
  const nameIn = useIn(10);
  const titleIn = useIn(20);
  const out = useOut(180, 18);
  const w = interpolate(bar, [0, 1], [0, 760]);
  return (
    <AbsoluteFill style={{background: showBackdrop ? 'linear-gradient(135deg,#3a3a48,#16161c)' : 'transparent'}}>
      <div style={{position: 'absolute', right: 120, bottom: 140, opacity: out, direction: 'rtl'}}>
        <div style={{position: 'absolute', right: 0, top: 0, width: 12, height: 150, background: accent, borderRadius: 6, transform: `scaleY(${bar})`}} />
        <div style={{marginRight: 34, width: w, overflow: 'hidden', background: 'rgba(10,6,30,0.82)', borderRadius: 20, padding: w > 40 ? '18px 36px' : 0}}>
          <Txt size={62} style={{whiteSpace: 'nowrap', opacity: nameIn, transform: `translateX(${(1 - nameIn) * 60}px)`}}>{name}</Txt>
          <Txt size={34} weight={700} color={accent} style={{whiteSpace: 'nowrap', opacity: titleIn}}>{title}</Txt>
        </div>
      </div>
      <div style={{display: 'none'}}>{frame}</div>
    </AbsoluteFill>
  );
};
