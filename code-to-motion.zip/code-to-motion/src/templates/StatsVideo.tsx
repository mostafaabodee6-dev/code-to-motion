// قالب 08 — فيديو إحصائيات (10 ثواني): أرقام تعد من صفر + أعمدة بيانية
import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, Easing} from 'remotion';
import {z} from 'zod';
import {zColor} from '@remotion/zod-types';
import {Background} from '../components/Background';
import {useIn, Txt} from './kit';

export const statsSchema = z.object({
  title: z.string(),
  stats: z.array(z.object({label: z.string(), value: z.number(), suffix: z.string()})).min(2).max(4),
  source: z.string(),
  accent: zColor(),
});
export const STATS_DURATION = 300;

export const StatsVideo: React.FC<z.infer<typeof statsSchema>> = ({title, stats, source, accent}) => {
  const frame = useCurrentFrame();
  const head = useIn(0);
  const max = Math.max(...stats.map((s) => s.value));
  // لو كل الأرقام نفس الوحدة نقارن الأطوال، غير كذا كل الأعمدة نفس الطول
  const same = stats.every((s) => s.suffix === stats[0].suffix);
  return (
    <AbsoluteFill style={{padding: '110px 140px'}}>
      <Background />
      <Txt size={84} style={{opacity: head, transform: `translateY(${(1 - head) * 40}px)`}}>{title}</Txt>
      <div style={{position: 'relative', flex: 1, display: 'flex', alignItems: 'flex-end', gap: 70, direction: 'rtl', marginTop: 40}}>
        {stats.map((s, i) => {
          const start = 30 + i * 15;
          const p = interpolate(frame, [start, start + 60], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
          return (
            <div key={i} style={{flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16}}>
              <div style={{fontFamily: 'Cairo', fontWeight: 900, fontSize: 92, color: '#fff', direction: 'ltr'}}>{Math.round(s.value * p).toLocaleString('en-US')}{s.suffix}</div>
              <div style={{width: '100%', height: 520 * (same ? s.value / max : 0.75) * p, background: `linear-gradient(180deg, ${accent}, ${accent}55)`, borderRadius: '24px 24px 6px 6px'}} />
              <Txt size={40} weight={700} color="#D3CAF2" style={{textAlign: 'center'}}>{s.label}</Txt>
            </div>
          );
        })}
      </div>
      <Txt size={26} weight={400} color="#D3CAF2" style={{position: 'relative', marginTop: 20, opacity: interpolate(frame, [120, 150], [0, 0.8], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}}>{source}</Txt>
    </AbsoluteFill>
  );
};
