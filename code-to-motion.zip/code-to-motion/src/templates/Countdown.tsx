// قالب 07 — عداد تنازلي للفعاليات: غيّر عدد الثواني من Props
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame, useVideoConfig, interpolate} from 'remotion';
import {z} from 'zod';
import {zColor} from '@remotion/zod-types';
import {Background} from '../components/Background';
import {Txt} from './kit';

export const countdownSchema = z.object({
  title: z.string(),
  seconds: z.number().int().min(3).max(600),
  endText: z.string(),
  accent: zColor(),
});
// المدة تتحسب من seconds (calculateMetadata في Root.tsx)

export const Countdown: React.FC<z.infer<typeof countdownSchema>> = ({title, seconds, endText, accent}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const left = Math.max(0, seconds - Math.floor(frame / fps));
  const inSec = (frame % fps) / fps; // 0 → 1 داخل كل ثانية
  const done = frame >= seconds * fps;
  const mm = String(Math.floor(left / 60)).padStart(2, '0'), ss = String(left % 60).padStart(2, '0');
  const ring = 2 * Math.PI * 330;
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
      <Background />
      <Txt size={64} weight={700} style={{position: 'absolute', top: 110}}>{title}</Txt>
      {!done ? (
        <>
          <svg width={760} height={760} style={{position: 'absolute', transform: 'rotate(-90deg)'}}>
            <circle cx={380} cy={380} r={330} stroke="rgba(255,255,255,.15)" strokeWidth={22} fill="none" />
            <circle cx={380} cy={380} r={330} stroke={accent} strokeWidth={22} fill="none" strokeLinecap="round" strokeDasharray={ring} strokeDashoffset={ring * inSec} />
          </svg>
          <div style={{fontFamily: 'Cairo', fontWeight: 900, fontSize: 230, color: '#fff', direction: 'ltr', transform: `scale(${1 + (1 - inSec) * 0.06})`}}>{mm}:{ss}</div>
        </>
      ) : (
        <Txt size={170} color={accent} style={{transform: `scale(${interpolate(frame - seconds * fps, [0, 12], [0.6, 1], {extrapolateRight: 'clamp'})})`}}>{endText}</Txt>
      )}
      {Array.from({length: seconds}, (_, i) => (
        <Sequence key={i} from={i * fps} durationInFrames={fps}><Audio src={staticFile('sfx/click.wav')} volume={0.35} /></Sequence>
      ))}
      <Sequence from={seconds * fps}><Audio src={staticFile('sfx/hit.wav')} volume={0.7} /></Sequence>
    </AbsoluteFill>
  );
};
