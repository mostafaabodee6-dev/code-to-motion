// أدوات مشتركة للقوالب
import React from 'react';
import {spring, useCurrentFrame, useVideoConfig, interpolate} from 'remotion';
import {FONT} from '../theme';

// قيمة دخول spring من فريم معيّن
export const useIn = (start: number, damping = 13) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: frame - start, fps, config: {damping}});
};
// قيمة خروج: 1 → 0 في آخر "len" فريم قبل "end"
export const useOut = (end: number, len = 15) => {
  const frame = useCurrentFrame();
  return interpolate(frame, [end - len, end], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
};
export const Txt: React.FC<{size: number; color?: string; weight?: number; style?: React.CSSProperties; children: React.ReactNode}> = ({
  size, color = '#fff', weight = 900, style, children,
}) => <div style={{fontFamily: FONT, fontSize: size, fontWeight: weight, color, direction: 'rtl', lineHeight: 1.3, ...style}}>{children}</div>;
