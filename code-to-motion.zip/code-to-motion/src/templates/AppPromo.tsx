// قالب 04 — إعلان تطبيق (12 ثانية): جوال في النص، صورة شاشتك داخله، ومميزات تطلع حوله
import React from 'react';
import {AbsoluteFill, Img, Sequence, staticFile, interpolate, useCurrentFrame} from 'remotion';
import {z} from 'zod';
import {zColor} from '@remotion/zod-types';
import {Background} from '../components/Background';
import {useIn, Txt} from './kit';

export const appPromoSchema = z.object({
  appName: z.string(),
  headline: z.string(),
  screenshot: z.string(), // صورة شاشة التطبيق داخل public (عمودية)
  features: z.array(z.string()).length(3),
  cta: z.string(),
  accent: zColor(),
});
export const APP_PROMO_DURATION = 360;

const Phone: React.FC<{src: string; accent: string}> = ({src, accent}) => {
  const p = useIn(10, 14);
  const frame = useCurrentFrame();
  const float = Math.sin(frame / 25) * 10;
  return (
    <div style={{width: 380, height: 780, borderRadius: 60, background: '#0b0620', border: '12px solid #1f1640', boxShadow: `0 40px 120px ${accent}55`, overflow: 'hidden',
      transform: `translateY(${(1 - p) * 500 + float}px) rotate(${(1 - p) * 12}deg)`}}>
      <Img src={staticFile(src)} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
    </div>
  );
};

export const AppPromo: React.FC<z.infer<typeof appPromoSchema>> = ({appName, headline, screenshot, features, cta, accent}) => {
  const frame = useCurrentFrame();
  const head = useIn(30);
  const ctaIn = useIn(270, 10);
  return (
    <AbsoluteFill>
      <Background />
      <AbsoluteFill style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 120, direction: 'rtl'}}>
        <div style={{width: 760}}>
          <Txt size={44} weight={700} color={accent} style={{opacity: head}}>{appName}</Txt>
          <Txt size={92} style={{opacity: head, transform: `translateY(${(1 - head) * 40}px)`}}>{headline}</Txt>
          <div style={{marginTop: 40, display: 'flex', flexDirection: 'column', gap: 22}}>
            {features.map((f, i) => (
              <Sequence key={i} from={90 + i * 45} layout="none">
                <Feature text={f} accent={accent} />
              </Sequence>
            ))}
          </div>
          <div style={{marginTop: 46, display: 'inline-block', background: accent, color: '#14063F', borderRadius: 999, padding: '16px 46px', fontFamily: 'Cairo', fontWeight: 900, fontSize: 44,
            transform: `scale(${ctaIn})`}}>{cta}</div>
        </div>
        <Phone src={screenshot} accent={accent} />
      </AbsoluteFill>
      <div style={{display: 'none'}}>{interpolate(frame, [0, 1], [0, 1])}</div>
    </AbsoluteFill>
  );
};
const Feature: React.FC<{text: string; accent: string}> = ({text, accent}) => {
  const p = useIn(0, 12);
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 20, opacity: p, transform: `translateX(${(1 - p) * -80}px)`}}>
      <div style={{width: 46, height: 46, borderRadius: 14, background: accent, color: '#14063F', fontFamily: 'Cairo', fontWeight: 900, fontSize: 30, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>✓</div>
      <Txt size={46} weight={700}>{text}</Txt>
    </div>
  );
};
