// نقطة البداية: هنا نسجّل كل الفيديوهات الموجودة في Root
import {registerRoot} from 'remotion';
import {RemotionRoot} from './Root';

registerRoot(RemotionRoot);
