// هنا نسجّل كل الفيديوهات (Compositions) اللي تظهر في Remotion Studio
// كل Composition لها: id، component، المدة بالفريمات، fps، العرض والطول

import React from 'react';
import {Composition, Folder} from 'remotion';
import {FPS, HEIGHT, WIDTH} from './theme';
import {L01_FirstAnimation} from './lessons/L01_FirstAnimation';
import {L02_Interpolate} from './lessons/L02_Interpolate';
import {L03_Spring} from './lessons/L03_Spring';
import {L04_Sequence} from './lessons/L04_Sequence';
import {L05_Transitions} from './lessons/L05_Transitions';
import {L06_Media} from './lessons/L06_Media';
import {FinalProject, FINAL_DURATION} from './final/FinalProject';
import {finalSchema} from './final/schema';
import {Intro, INTRO_DURATION} from './intro/Intro';
import {AboutMe, aboutMeSchema} from './challenge/AboutMe';

const base = {fps: FPS, width: WIDTH, height: HEIGHT};

export const RemotionRoot: React.FC = () => (
  <>
    <Composition id="Intro" component={Intro} durationInFrames={INTRO_DURATION} {...base} />

    <Folder name="Lessons">
      <Composition id="L01-FirstAnimation" component={L01_FirstAnimation} durationInFrames={90} {...base} />
      <Composition id="L02-Interpolate" component={L02_Interpolate} durationInFrames={120} {...base} />
      <Composition id="L03-Spring" component={L03_Spring} durationInFrames={120} {...base} />
      <Composition id="L04-Sequence" component={L04_Sequence} durationInFrames={180} {...base} />
      {/* 50+50+50+60 − (15+20+20) = 155 فريم */}
      <Composition id="L05-Transitions" component={L05_Transitions} durationInFrames={155} {...base} />
      <Composition id="L06-Media" component={L06_Media} durationInFrames={150} {...base} />
    </Folder>

    <Composition
      id="FinalProject"
      component={FinalProject}
      durationInFrames={FINAL_DURATION}
      {...base}
      schema={finalSchema}
      defaultProps={{
        hook: 'كل فيديو عظيم يبدأ بـ فكرة',
        problem: 'أدوات كثيرة. وقت أطول.',
        solution: 'فكرة وحدة… وكود واحد',
        title: 'CODE TO MOTION',
        tagline: 'اصنع موشن جرافيك احترافي بالكود',
        presenter: 'عبدالرحمن مصطفى',
        accent: '#FFD84D',
      }}
    />

    <Composition
      id="AboutMe"
      component={AboutMe}
      durationInFrames={300}
      {...base}
      schema={aboutMeSchema}
      defaultProps={{name: 'اسمك هنا', role: 'مصمم وصانع محتوى', skills: ['تصميم', 'مونتاج', 'موشن'], accent: '#4FF0FF'}}
    />
  </>
);
