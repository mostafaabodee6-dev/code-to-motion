// هنا نسجّل كل الفيديوهات (Compositions) اللي تظهر في Remotion Studio
// كل Composition لها: id، component، المدة بالفريمات، fps، العرض والطول

import React from 'react';
import {Composition, Folder} from 'remotion';
import {FPS, HEIGHT, WIDTH} from './theme';
import {L01_FirstAnimation} from './lessons/L01_FirstAnimation';
import {L02_Interpolate} from './lessons/L02_Interpolate';
import {L03_Spring} from './lessons/L03_Spring';
import {L04_Sequence} from './lessons/L04_Sequence';
import {L05_Transitions} from './lessons/L05_Transitions';
import {L06_Media} from './lessons/L06_Media';
import {FinalProject, FINAL_DURATION} from './final/FinalProject';
import {finalSchema} from './final/schema';
import {Intro, INTRO_DURATION} from './intro/Intro';
import {AboutMe, aboutMeSchema} from './challenge/AboutMe';
import {SpeakerIntro, SPEAKER_DURATION} from './live/SpeakerIntro';
import {QnALoop, QNA_DURATION} from './live/QnALoop';
import {Closing, CLOSING_DURATION} from './live/Closing';
import {LIVE_FPS} from './live/common';
import {Promo, PROMO_DURATION} from './promo/Promo';
import {LogoReveal, logoRevealSchema, LOGO_REVEAL_DURATION} from './templates/LogoReveal';
import {LowerThird, lowerThirdSchema, LOWER_THIRD_DURATION} from './templates/LowerThird';
import {AppPromo, appPromoSchema, APP_PROMO_DURATION} from './templates/AppPromo';
import {SocialReel, socialReelSchema, SOCIAL_REEL_DURATION} from './templates/SocialReel';
import {Explainer, explainerSchema, EXPLAINER_DURATION} from './templates/Explainer';
import {Countdown, countdownSchema} from './templates/Countdown';
import {StatsVideo, statsSchema, STATS_DURATION} from './templates/StatsVideo';

const base = {fps: FPS, width: WIDTH, height: HEIGHT};

export const RemotionRoot: React.FC = () => (
  <>
    <Composition id="Intro" component={Intro} durationInFrames={INTRO_DURATION} {...base} />

    {/* الإعلان الترويجي العمودي */}
    <Composition id="Promo" component={Promo} durationInFrames={PROMO_DURATION} fps={30} width={1080} height={1920} />

    {/* شاشات البث المباشر — 60fps */}
    <Folder name="Live">
      <Composition id="SpeakerIntro" component={SpeakerIntro} durationInFrames={SPEAKER_DURATION} {...base} fps={LIVE_FPS} />
      <Composition id="QnALoop" component={QnALoop} durationInFrames={QNA_DURATION} {...base} fps={LIVE_FPS} />
      <Composition id="Closing" component={Closing} durationInFrames={CLOSING_DURATION} {...base} fps={LIVE_FPS} />
    </Folder>

    {/* 8 قوالب جاهزة — غيّر كل شي من لوحة Props */}
    <Folder name="Templates">
      <Composition id="T01-AboutMe" component={AboutMe} durationInFrames={300} {...base} schema={aboutMeSchema}
        defaultProps={{name: 'اسمك هنا', role: 'مصمم وصانع محتوى', skills: ['تصميم', 'مونتاج', 'موشن'], accent: '#4FF0FF'}} />
      <Composition id="T02-LogoReveal" component={LogoReveal} durationInFrames={LOGO_REVEAL_DURATION} {...base} schema={logoRevealSchema}
        defaultProps={{logo: 'logo.png', brand: 'اسم علامتك', tagline: 'جملة قصيرة عن علامتك', bg: '#14063F', accent: '#FF2E9A'}} />
      <Composition id="T03-LowerThird" component={LowerThird} durationInFrames={LOWER_THIRD_DURATION} {...base} schema={lowerThirdSchema}
        defaultProps={{name: 'عبدالرحمن مصطفى', title: 'مصمم جرافيك وصانع محتوى', accent: '#FFD84D', showBackdrop: true}} />
      <Composition id="T04-AppPromo" component={AppPromo} durationInFrames={APP_PROMO_DURATION} {...base} schema={appPromoSchema}
        defaultProps={{appName: 'اسم تطبيقك', headline: 'كل اللي تحتاجه في مكان واحد', screenshot: 'templates/app-screen.jpg',
          features: ['سريع وسهل', 'يدعم العربي', 'مجاني للبداية'], cta: 'حمّله الحين', accent: '#4FF0FF'}} />
      <Composition id="T05-SocialReel" component={SocialReel} durationInFrames={SOCIAL_REEL_DURATION} fps={30} width={1080} height={1920} schema={socialReelSchema}
        defaultProps={{hook: '3 أسرار للموشن الاحترافي', points: ['حركة وحدة واضحة لكل مشهد', 'استخدم spring بدل الحركة الخطية', 'خلّ النص داخل الهامش الآمن'], handle: '@yourhandle', accent: '#FFD84D'}} />
      <Composition id="T06-Explainer" component={Explainer} durationInFrames={EXPLAINER_DURATION} {...base} schema={explainerSchema}
        defaultProps={{question: 'كيف تصنع فيديو بالكود؟', steps: [{title: 'فكرة', text: 'اكتب وش تبي يوصل للمشاهد في جملة'}, {title: 'برومبت', text: 'وصّف المشاهد للوكيل بالتفصيل'}, {title: 'صدّر', text: 'راجع في Studio وبعدين render'}], summary: 'فكرة ← كود ← فيديو', accent: '#FF2E9A'}} />
      <Composition id="T07-Countdown" component={Countdown} durationInFrames={330} {...base} schema={countdownSchema}
        defaultProps={{title: 'نبدأ بعد', seconds: 10, endText: 'يلا نبدأ', accent: '#4FF0FF'}}
        calculateMetadata={({props}) => ({durationInFrames: props.seconds * FPS + 60})} />
      <Composition id="T08-Stats" component={StatsVideo} durationInFrames={STATS_DURATION} {...base} schema={statsSchema}
        defaultProps={{title: 'أرقام السنة', stats: [{label: 'زائر', value: 12500, suffix: '+'}, {label: 'مشترك', value: 3400, suffix: ''}, {label: 'رضا العملاء', value: 96, suffix: '%'}], source: 'مثال: غيّر الأرقام لبياناتك الحقيقية', accent: '#FFD84D'}} />
    </Folder>

    <Folder name="Lessons">
      <Composition id="L01-FirstAnimation" component={L01_FirstAnimation} durationInFrames={90} {...base} />
      <Composition id="L02-Interpolate" component={L02_Interpolate} durationInFrames={120} {...base} />
      <Composition id="L03-Spring" component={L03_Spring} durationInFrames={120} {...base} />
      <Composition id="L04-Sequence" component={L04_Sequence} durationInFrames={180} {...base} />
      {/* 50+50+50+60 − (15+20+20) = 155 فريم */}
      <Composition id="L05-Transitions" component={L05_Transitions} durationInFrames={155} {...base} />
      <Composition id="L06-Media" component={L06_Media} durationInFrames={150} {...base} />
    </Folder>

    <Composition
      id="FinalProject"
      component={FinalProject}
      durationInFrames={FINAL_DURATION}
      {...base}
      schema={finalSchema}
      defaultProps={{
        hook: 'كل فيديو عظيم يبدأ بـ فكرة',
        problem: 'أدوات كثيرة. وقت أطول.',
        solution: 'فكرة وحدة… وكود واحد',
        title: 'CODE TO MOTION',
        tagline: 'اصنع موشن جرافيك احترافي بالكود',
        presenter: 'عبدالرحمن مصطفى',
        accent: '#FFD84D',
      }}
    />

    <Composition
      id="AboutMe"
      component={AboutMe}
      durationInFrames={300}
      {...base}
      schema={aboutMeSchema}
      defaultProps={{name: 'اسمك هنا', role: 'مصمم وصانع محتوى', skills: ['تصميم', 'مونتاج', 'موشن'], accent: '#4FF0FF'}}
    />
  </>
);
