// 🏆 تحدي الورشة — فيديو 10 ثواني عن نفسك
// افتح Remotion Studio واختار AboutMe، وغيّر اسمك ووصفك ومهاراتك من لوحة Props
// وبعدين صدّره:  npx remotion render AboutMe out/about-me.mp4

import React from 'react';
import {AbsoluteFill, Audio, interpolate, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {z} from 'zod';
import {zColor} from '@remotion/zod-types';
import {Background} from '../components/Background';
import {Words} from '../components/Words';
import {COLORS, FONT} from '../theme';

export const aboutMeSchema = z.object({
  name: z.string(),
  role: z.string(),
  skills: z.array(z.string()).max(4),
  accent: zColor(),
});

type Props = z.infer<typeof aboutMeSchema>;

const Skills: React.FC<{skills: string[]; accent: string}> = ({skills, accent}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <div style={{display: 'flex', flexDirection: 'row-reverse', gap: 40, flexWrap: 'wrap', justifyContent: 'center'}}>
      {skills.map((s, i) => {
        const p = spring({frame: frame - i * 8, fps, config: {damping: 10}});
        return (
          <div
            key={i}
            style={{
              padding: '30px 60px',
              borderRadius: 999,
              background: accent,
              color: COLORS.bg,
              fontFamily: FONT,
              fontWeight: 900,
              fontSize: 64,
              transform: `scale(${p})`,
            }}
          >
            {s}
          </div>
        );
      })}
    </div>
  );
};

export const AboutMe: React.FC<Props> = ({name, role, skills, accent}) => {
  const frame = useCurrentFrame();
  const end = interpolate(frame, [250, 270], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill>
      <Background />
      <Sequence durationInFrames={110}>
        <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'column', gap: 30}}>
          <Words text="أهلًا، أنا" size={90} color={COLORS.muted} />
          <Words text={name} start={12} size={170} color={accent} />
        </AbsoluteFill>
      </Sequence>
      <Sequence from={110} durationInFrames={70}>
        <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
          <Words text={role} size={130} />
        </AbsoluteFill>
      </Sequence>
      <Sequence from={180} durationInFrames={70}>
        <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
          <Skills skills={skills} accent={accent} />
        </AbsoluteFill>
      </Sequence>
      <Sequence from={250}>
        <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', opacity: end}}>
          <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 60, color: COLORS.white, direction: 'rtl'}}>صنعته بالكود في ورشة</div>
          <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 120, color: accent}}>CODE TO MOTION</div>
        </AbsoluteFill>
      </Sequence>
      <Audio src={staticFile('sfx/music.wav')} volume={0.35} />
      {[0, 110, 180, 250].map((f) => (
        <Sequence key={f} from={f}>
          <Audio src={staticFile('sfx/whoosh.wav')} volume={0.5} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
