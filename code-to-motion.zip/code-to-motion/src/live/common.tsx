// أدوات مشتركة لشاشات البث المباشر (60fps)
import React from 'react';
import {AbsoluteFill, interpolate, Easing, useCurrentFrame, Img, staticFile} from 'remotion';
import {COLORS, FONT} from '../theme';

export const LIVE_FPS = 60;

// خلفية تتحرك بشكل دوري: بعد "period" فريم ترجع لنفس الشكل بالضبط (مهم للـ loop)
export const LoopBg: React.FC<{period: number}> = ({period}) => {
  const frame = useCurrentFrame();
  const a = (k: number) => (2 * Math.PI * k * frame) / period;
  const blob = (c: string, x: number, y: number, r: number) =>
    `radial-gradient(circle ${r}px at ${x}px ${y}px, ${c}bb, transparent 70%)`;
  return (
    <AbsoluteFill
      style={{
        backgroundColor: COLORS.bg,
        backgroundImage: [
          blob(COLORS.pink, 1650 + Math.sin(a(1)) * 90, 160 + Math.cos(a(1)) * 60, 760),
          blob(COLORS.blue, 260 + Math.cos(a(1)) * 100, 940 + Math.sin(a(2)) * 50, 720),
          blob(COLORS.violet, 1100 + Math.sin(a(2)) * 120, 1000 + Math.cos(a(1)) * 40, 660),
        ].join(','),
      }}
    />
  );
};

// يدخل ويطلع بنعومة: fade + حركة بسيطة لفوق
export const Enter: React.FC<{
  from: number; to: number; delay?: number; children: React.ReactNode; style?: React.CSSProperties;
}> = ({from, to, delay = 0, children, style}) => {
  const f = useCurrentFrame();
  const inP = interpolate(f, [from + delay, from + delay + 30], [0, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic),
  });
  const outP = interpolate(f, [to - 24, to], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  if (f < from || f > to) return null;
  return (
    <div style={{opacity: inP * outP, transform: `translateY(${(1 - inP) * 50}px) scale(${0.96 + inP * 0.04})`, ...style}}>
      {children}
    </div>
  );
};

export const T: React.FC<{size: number; color?: string; weight?: number; children: React.ReactNode; style?: React.CSSProperties}> = ({
  size, color = COLORS.white, weight = 900, children, style,
}) => (
  <div style={{fontFamily: FONT, fontSize: size, fontWeight: weight, color, direction: 'rtl', lineHeight: 1.3, textAlign: 'center', ...style}}>
    {children}
  </div>
);

export const Corner: React.FC = () => (
  <div style={{position: 'absolute', top: 50, right: 70, display: 'flex', alignItems: 'center', gap: 18}}>
    <Img src={staticFile('logo.png')} style={{width: 70, height: 70, borderRadius: 18, objectFit: 'cover'}} />
    <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 30, color: COLORS.white, letterSpacing: 4}}>CODE TO MOTION</div>
  </div>
);

export const Card: React.FC<{children: React.ReactNode; accent: string; style?: React.CSSProperties}> = ({children, accent, style}) => (
  <div
    style={{
      background: 'rgba(255,255,255,0.08)', border: `2px solid ${accent}88`, borderRadius: 40,
      padding: '56px 80px', boxShadow: `0 30px 90px ${accent}33`, backdropFilter: 'blur(10px)', ...style,
    }}
  >
    {children}
  </div>
);
