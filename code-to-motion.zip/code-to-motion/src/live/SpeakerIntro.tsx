// تعريف المقدّم — 25 ثانية، 60fps، بدون تعليق صوتي
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {COLORS} from '../theme';
import {Card, Corner, Enter, LoopBg, T} from './common';

export const SPEAKER_DURATION = 25 * 60; // 1500

const S = {
  open: [0, 210], name: [200, 520], hawiyatak: [510, 870], jadvora: [860, 1170], end: [1160, 1500],
} as const;

export const SpeakerIntro: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const logoP = spring({frame: f - 10, fps, config: {damping: 14}});
  const endP = spring({frame: f - S.end[0] - 10, fps, config: {damping: 12}});
  return (
    <AbsoluteFill>
      <LoopBg period={1500} />
      {f > S.name[0] && f < S.end[0] && <Corner />}

      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
        <Enter from={S.open[0]} to={S.open[1]}>
          <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 30}}>
            <Img src={staticFile('logo.png')} style={{width: 220, height: 220, borderRadius: 50, objectFit: 'cover', transform: `scale(${logoP})`}} />
            <T size={56} color={COLORS.muted} weight={700}>مقدّم الورشة</T>
          </div>
        </Enter>

        <Enter from={S.name[0]} to={S.name[1]}>
          <T size={150}>عبدالرحمن مصطفى</T>
          <T size={54} color={COLORS.cyan} weight={700} style={{direction: 'ltr'}}>Graphic Designer &amp; Video Editor</T>
          <Enter from={S.name[0]} to={S.name[1]} delay={40}>
            <T size={44} color={COLORS.muted} weight={700} style={{marginTop: 30}}>مؤلف كتاب "قبل أن تبلغ العشرين"</T>
          </Enter>
        </Enter>

        <Enter from={S.hawiyatak[0]} to={S.hawiyatak[1]}>
          <Card accent={COLORS.pink}>
            <T size={40} color={COLORS.pink} weight={700}>من مشاريعي</T>
            <T size={140}>هويتك</T>
            <T size={50} color={COLORS.muted} weight={700}>منصة بطاقات أعمال رقمية عربية</T>
            <Enter from={S.hawiyatak[0]} to={S.hawiyatak[1]} delay={50}>
              <div style={{marginTop: 34, display: 'flex', justifyContent: 'center', gap: 20, alignItems: 'baseline'}}>
                <T size={110} color={COLORS.yellow}>13</T>
                <T size={50} weight={700}>دولة وصلها الموقع</T>
              </div>
            </Enter>
          </Card>
        </Enter>

        <Enter from={S.jadvora[0]} to={S.jadvora[1]}>
          <Card accent={COLORS.cyan}>
            <T size={40} color={COLORS.cyan} weight={700}>ومشروع ثاني</T>
            <T size={140}>جادفورا</T>
            <T size={50} color={COLORS.muted} weight={700}>منصة لإدارة المحتوى والنشر الرقمي</T>
          </Card>
        </Enter>

        <Enter from={S.end[0]} to={S.end[1] + 30}>
          <div style={{transform: `scale(${0.8 + endP * 0.2})`}}>
            <T size={60} color={COLORS.muted} weight={700}>ورشة</T>
            <div style={{fontFamily: 'Cairo', fontWeight: 900, fontSize: 190, color: COLORS.white, letterSpacing: 6, textAlign: 'center',
              textShadow: `0 0 60px ${COLORS.pink}88`}}>CODE TO MOTION</div>
            <T size={62} color={COLORS.yellow} style={{direction: 'ltr'}}>Let's turn code into motion</T>
            <T size={46} color={COLORS.white} weight={700} style={{marginTop: 10}}>يلا نحوّل الكود إلى حركة</T>
          </div>
        </Enter>
      </AbsoluteFill>

      {/* مؤثرات خفيفة عند كل انتقال — بدون تعليق صوتي */}
      {[S.name[0], S.hawiyatak[0], S.jadvora[0]].map((s) => (
        <Sequence key={s} from={s}><Audio src={staticFile('sfx/whoosh.wav')} volume={0.5} /></Sequence>
      ))}
      <Sequence from={S.end[0] + 6}><Audio src={staticFile('sfx/hit.wav')} volume={0.6} /></Sequence>
      <Audio src={staticFile('sfx/music.wav')} volume={(fr) => interpolate(fr, [0, 60, 1380, 1500], [0, 0.25, 0.25, 0], {extrapolateRight: 'clamp'})} />
    </AbsoluteFill>
  );
};
