// شاشة الأسئلة — 20 ثانية، 60fps، loop بدون أي قفزة، بدون صوت (للـ OBS)
// القاعدة: كل حركة دورية على 1200 فريم → الفريم الأخير يركب على الأول
import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {COLORS, FONT} from '../theme';
import {Corner, LoopBg, T} from './common';

export const QNA_DURATION = 20 * 60; // 1200
const P = QNA_DURATION;

export const QnALoop: React.FC = () => {
  const f = useCurrentFrame();
  const w = (k: number) => (2 * Math.PI * k * f) / P;
  const pulse = 1 + Math.sin(w(4)) * 0.03;

  // علامات استفهام تطلع لفوق وترجع من تحت (mod) — دورة كاملة كل 1200 فريم
  const marks = Array.from({length: 14}, (_, i) => {
    const prog = ((f / P) * (i % 2 ? 1 : 2) + i / 14) % 1;
    const x = (i * 137) % 1920;
    const y = 1150 - prog * 1300;
    const s = 40 + ((i * 53) % 70);
    return {x, y, s, o: Math.sin(prog * Math.PI) * 0.35, r: Math.sin(w(1) + i) * 20};
  });

  return (
    <AbsoluteFill>
      <LoopBg period={P} />
      {marks.map((m, i) => (
        <div key={i} style={{position: 'absolute', left: m.x, top: m.y, fontFamily: FONT, fontWeight: 900, fontSize: m.s,
          color: i % 3 === 0 ? COLORS.cyan : i % 3 === 1 ? COLORS.pink : COLORS.yellow, opacity: m.o, transform: `rotate(${m.r}deg)`}}>
          ؟
        </div>
      ))}
      <Corner />

      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
        {[0, 1, 2].map((k) => {
          const p = ((f / P) * 4 + k / 3) % 1; // 4 نبضات في الدورة
          return (
            <div key={k} style={{position: 'absolute', width: 380 + p * 700, height: 380 + p * 700, borderRadius: '50%',
              border: `3px solid ${COLORS.cyan}`, opacity: (1 - p) * 0.35}} />
          );
        })}
        <div style={{transform: `scale(${pulse})`}}>
          <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 210, color: COLORS.white, textAlign: 'center', letterSpacing: 10,
            textShadow: `0 0 70px ${COLORS.pink}aa`}}>Q&amp;A</div>
          <T size={110}>وقت الأسئلة</T>
          <T size={50} color={COLORS.yellow} weight={700} style={{marginTop: 20}}>اكتب سؤالك في الشات</T>
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
