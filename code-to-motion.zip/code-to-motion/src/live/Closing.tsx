// شاشة الختام — 30 ثانية، 60fps، QR لموقع موارد الورشة + حساباتي
import React from 'react';
import {AbsoluteFill, Audio, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {COLORS, FONT} from '../theme';
import {Card, Enter, LoopBg, T} from './common';

export const CLOSING_DURATION = 30 * 60; // 1800
const SITE = 'mostafaabodee6-dev.github.io/code-to-motion';

const handles = [
  {k: 'X · Instagram · Threads', v: '@mostafaabodee8', c: COLORS.pink},
  {k: 'YouTube', v: '@abdulrahmanmostafa-f7c', c: COLORS.yellow},
  {k: 'Email', v: 'mostafaabodee9@gmail.com', c: COLORS.cyan},
];

export const Closing: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const big = spring({frame: f - 15, fps, config: {damping: 12}});
  const qr = spring({frame: f - 330, fps, config: {damping: 14}});
  return (
    <AbsoluteFill>
      <LoopBg period={1800} />

      {/* المرحلة 1: شكرًا */}
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
        <Enter from={0} to={300}>
          <div style={{transform: `scale(${0.7 + big * 0.3})`}}>
            <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 230, color: COLORS.white, letterSpacing: 12, textAlign: 'center',
              textShadow: `0 0 80px ${COLORS.pink}99`}}>THANK YOU</div>
            <T size={90}>شكرًا لحضوركم</T>
            <T size={46} color={COLORS.muted} weight={700}>ورشة CODE TO MOTION · عبدالرحمن مصطفى</T>
          </div>
        </Enter>
      </AbsoluteFill>

      {/* المرحلة 2: QR + الحسابات (تبقى للنهاية) */}
      <Enter from={300} to={1830} style={{position: 'absolute', inset: 0}}>
        <AbsoluteFill style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 110, direction: 'rtl', padding: 80}}>
          <div style={{display: 'flex', flexDirection: 'column', gap: 26, minWidth: 820}}>
            <T size={84} style={{textAlign: 'right'}}>شكرًا لكم</T>
            <T size={40} color={COLORS.muted} weight={700} style={{textAlign: 'right', marginBottom: 10}}>تابعوني وشاركوني اللي تسوونه</T>
            {handles.map((h, i) => (
              <Enter key={h.v} from={300} to={1830} delay={40 + i * 20}>
                <Card accent={h.c} style={{padding: '22px 40px', borderRadius: 26}}>
                  <div style={{fontFamily: FONT, fontSize: 28, fontWeight: 700, color: h.c, direction: 'ltr', textAlign: 'left'}}>{h.k}</div>
                  <div style={{fontFamily: FONT, fontSize: 46, fontWeight: 900, color: COLORS.white, direction: 'ltr', textAlign: 'left'}}>{h.v}</div>
                </Card>
              </Enter>
            ))}
          </div>
          <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 24, transform: `scale(${qr})`}}>
            <div style={{background: 'white', padding: 26, borderRadius: 36, boxShadow: `0 0 0 6px ${COLORS.cyan}, 0 30px 90px ${COLORS.cyan}55`}}>
              <Img src={staticFile('qr-site.png')} style={{width: 420, height: 420, display: 'block'}} />
            </div>
            <T size={46}>موارد الورشة</T>
            <div style={{fontFamily: FONT, fontSize: 28, fontWeight: 700, color: COLORS.cyan, direction: 'ltr'}}>{SITE}</div>
          </div>
        </AbsoluteFill>
      </Enter>

      <Audio src={staticFile('sfx/closing.wav')} volume={(fr) => interpolate(fr, [0, 1700, 1800], [1, 1, 0], {extrapolateRight: 'clamp'})} />
    </AbsoluteFill>
  );
};
