// خلفية متدرّجة متحركة — نستخدمها في أغلب الدروس
import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {COLORS} from '../theme';

type Props = {
  colors?: [string, string, string];
};

export const Background: React.FC<Props> = ({colors = [COLORS.pink, COLORS.blue, COLORS.violet]}) => {
  const frame = useCurrentFrame();
  // Math.sin يعطينا حركة رايحة جاية بشكل ناعم
  const drift = (speed: number, size: number) => Math.sin(frame / speed) * size;

  const blob = (color: string, x: number, y: number, r: number) =>
    `radial-gradient(circle ${r}px at ${x}px ${y}px, ${color}cc, transparent 70%)`;

  return (
    <AbsoluteFill
      style={{
        backgroundColor: COLORS.bg,
        backgroundImage: [
          blob(colors[0], 1650 + drift(60, 80), 150 + drift(80, 60), 750),
          blob(colors[1], 250 + drift(70, 90), 950 + drift(50, 50), 700),
          blob(colors[2], 1100 + drift(90, 120), 1000 + drift(65, 40), 650),
        ].join(','),
      }}
    />
  );
};
