// عنوان صغير يوضح اسم الدرس فوق الشاشة
import React from 'react';
import {COLORS, FONT} from '../theme';

export const Label: React.FC<{text: string}> = ({text}) => (
  <div
    style={{
      position: 'absolute',
      top: 60,
      right: 80,
      padding: '10px 28px',
      borderRadius: 999,
      background: 'rgba(255,255,255,0.12)',
      border: '1.5px solid rgba(255,255,255,0.35)',
      color: COLORS.white,
      fontFamily: FONT,
      fontWeight: 700,
      fontSize: 30,
      direction: 'rtl',
    }}
  >
    {text}
  </div>
);
