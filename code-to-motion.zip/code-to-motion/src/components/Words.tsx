// نص يظهر كلمة كلمة بحركة spring (Kinetic Typography)
import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {COLORS, FONT} from '../theme';

type Props = {
  text: string;
  start?: number; // متى تبدأ أول كلمة
  gap?: number; // كم فريم بين كل كلمة والثانية
  size?: number;
  color?: string;
  highlight?: {word: string; color: string};
};

export const Words: React.FC<Props> = ({text, start = 0, gap = 5, size = 120, color = COLORS.white, highlight}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const words = text.split(' ');

  return (
    <div style={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: size * 0.28, direction: 'rtl', maxWidth: 1600}}>
      {words.map((w, i) => {
        const p = spring({frame: frame - start - i * gap, fps, config: {damping: 13}});
        const isHi = highlight && w.includes(highlight.word);
        return (
          <span
            key={i}
            style={{
              display: 'inline-block',
              fontFamily: FONT,
              fontWeight: 900,
              fontSize: size,
              lineHeight: 1.25,
              color: isHi ? highlight!.color : color,
              opacity: Math.min(1, p * 1.5),
              transform: `translateY(${(1 - p) * 80}px) scale(${0.7 + p * 0.3})`,
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};
