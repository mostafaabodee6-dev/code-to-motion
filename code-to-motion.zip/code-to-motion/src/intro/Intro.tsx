// فيديو افتتاح الورشة (29 ثانية) — مصنوع بالكامل بـ Remotion
// الصوت: voice/intro.mp3 (ElevenLabs)، وكل مشهد مضبوط على وقت الكلام
// تشغّله أول الورشة، وفي النهاية تقول للحضور: "هذا الفيديو كله كود!"

import React from 'react';
import {AbsoluteFill, Audio, Img, interpolate, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Background} from '../components/Background';
import {Words} from '../components/Words';
import {COLORS, FONT} from '../theme';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// يغلّف أي مشهد بظهور واختفاء ناعم
const FadeScene: React.FC<{dur: number; children: React.ReactNode}> = ({dur, children}) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [0, 8, dur - 10, dur], [0, 1, 1, 0], clamp);
  const s = interpolate(frame, [0, dur], [1, 1.04]);
  return <AbsoluteFill style={{opacity: o, transform: `scale(${s})`, justifyContent: 'center', alignItems: 'center'}}>{children}</AbsoluteFill>;
};

const Title: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const letters = 'CODE TO MOTION'.split('');
  const sub = spring({frame: frame - 20, fps, config: {damping: 200}});
  return (
    <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
      <div style={{display: 'flex', direction: 'ltr'}}>
        {letters.map((l, i) => {
          const p = spring({frame: frame - i * 2, fps, config: {damping: 10, mass: 0.6}});
          return (
            <span
              key={i}
              style={{
                fontFamily: FONT,
                fontWeight: 900,
                fontSize: 190,
                color: COLORS.white,
                width: l === ' ' ? 60 : undefined,
                display: 'inline-block',
                transform: `translateY(${(1 - p) * -200}px) rotate(${(1 - p) * 30}deg)`,
                opacity: Math.min(1, p * 2),
                textShadow: `0 0 60px ${COLORS.pink}aa`,
              }}
            >
              {l}
            </span>
          );
        })}
      </div>
      <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 60, color: COLORS.cyan, direction: 'rtl', opacity: sub, transform: `translateY(${(1 - sub) * 30}px)`}}>
        اصنع موشن جرافيك احترافي بالكود
      </div>
    </div>
  );
};

const Presenter: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const card = spring({frame, fps, config: {damping: 14}});
  // كل سطر يظهر مع الكلام في التسجيل الصوتي
  const role = spring({frame: frame - 48, fps, config: {damping: 200}});
  const ai = spring({frame: frame - 101, fps, config: {damping: 200}});
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'row-reverse',
        alignItems: 'center',
        gap: 60,
        padding: '50px 70px',
        borderRadius: 50,
        background: 'rgba(20,6,63,0.55)',
        border: '2px solid rgba(255,255,255,0.25)',
        transform: `scale(${0.8 + card * 0.2})`,
        opacity: card,
      }}
    >
      <Img src={staticFile('logo.png')} style={{width: 320, height: 320, borderRadius: 50}} />
      <div style={{direction: 'rtl'}}>
        <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 110, color: COLORS.white, lineHeight: 1.2}}>عبدالرحمن مصطفى</div>
        <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 52, color: COLORS.cyan, opacity: role, transform: `translateX(${(1 - role) * -50}px)`}}>
          مصمم جرافيك ومونتير
        </div>
        <div style={{fontFamily: FONT, fontWeight: 400, fontSize: 44, color: COLORS.muted, opacity: ai, transform: `translateX(${(1 - ai) * -50}px)`}}>
          ومهتم جدًا بالذكاء الاصطناعي
        </div>
      </div>
    </div>
  );
};

const Goal: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tag = spring({frame: frame - 83, fps, config: {damping: 9}});
  return (
    <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 50}}>
      <Words text="الليلة بنصنع موشن جرافيك احترافي بالكود" size={100} gap={5} highlight={{word: 'بالكود', color: COLORS.yellow}} />
      <div
        style={{
          fontFamily: FONT,
          fontWeight: 900,
          fontSize: 120,
          color: COLORS.bg,
          background: COLORS.cyan,
          padding: '6px 60px 20px',
          borderRadius: 30,
          transform: `scale(${tag}) rotate(${(1 - tag) * -8}deg)`,
          direction: 'ltr',
        }}
      >
        Remotion
      </div>
    </div>
  );
};

// يظهر كل كلمة في الفريم اللي تنقال فيه بالضبط
const Motto: React.FC<{at: number[]}> = ({at}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const words = [
    ['Imagine.', COLORS.cyan],
    ['Build.', COLORS.yellow],
    ['Animate.', COLORS.pink],
  ];
  const lead = interpolate(frame, [0, 10], [0, 1], clamp);
  return (
    <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 30}}>
      <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 60, color: COLORS.muted, opacity: lead, direction: 'rtl'}}>وشعارنا الليلة</div>
      <div style={{display: 'flex', gap: 60, direction: 'ltr'}}>
        {words.map(([w, c], i) => {
          const p = spring({frame: frame - at[i], fps, config: {damping: 9}});
          return (
            <span key={w} style={{fontFamily: FONT, fontWeight: 900, fontSize: 150, color: c, transform: `scale(${p})`, display: 'inline-block'}}>
              {w}
            </span>
          );
        })}
      </div>
    </div>
  );
};

const Chat: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const b = spring({frame, fps, config: {damping: 12}});
  return (
    <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 40}}>
      <div
        style={{
          padding: '40px 70px',
          borderRadius: '60px 60px 60px 12px',
          background: COLORS.white,
          color: COLORS.bg,
          fontFamily: FONT,
          fontWeight: 900,
          fontSize: 84,
          direction: 'rtl',
          transform: `scale(${b})`,
          transformOrigin: 'bottom left',
        }}
      >
        اكتبوا في الشات
      </div>
      <Words text="من وين تحضرون معنا؟" start={14} size={90} gap={5} color={COLORS.cyan} />
    </div>
  );
};

const Start: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame, fps, config: {damping: 8}});
  const made = interpolate(frame, [25, 40], [0, 1], clamp);
  return (
    <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 40}}>
      <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 230, color: COLORS.yellow, transform: `scale(${p})`, direction: 'rtl', textShadow: `0 0 80px ${COLORS.pink}`}}>
        يلا نبدأ!
      </div>
      <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 44, color: COLORS.white, opacity: made, direction: 'rtl'}}>
        هذا الفيديو صُنع بالكامل بالكود باستخدام Remotion
      </div>
    </div>
  );
};

// ─── جدول المشاهد مضبوط على التسجيل الصوتي (voice/intro.mp3) ───
// [من فريم, المدة]  —  30 فريم = ثانية
const S = {
  salam: [0, 80], //      0.0s  السلام عليكم ورحمة الله وبركاته
  welcome: [78, 52], //   2.6s  وأهلًا وسهلًا فيكم في ورشة
  title: [127, 55], //    4.2s  CODE TO MOTION
  presenter: [180, 165], // 6.0s أنا عبدالرحمن مصطفى، مصمم جرافيك ومونتير، ومهتم بالذكاء الاصطناعي
  goal1: [345, 110], //  11.5s  الليلة هدفنا مو بس نتعلم أداة جديدة
  goal2: [455, 135], //  15.2s  الليلة بنصنع موشن جرافيك احترافي بالكود باستخدام Remotion
  motto: [590, 115], //  19.7s  وشعارنا الليلة: Imagine. Build. Animate.
  chat: [705, 76], //   23.5s  اكتبوا لنا في الشات من وين تحضرون معنا
  start: [781, 89], //  26.0s  ويلا نبدأ!
} as const;

export const INTRO_DURATION = 870; // 29 ثانية

const Scene: React.FC<{s: readonly [number, number]; children: React.ReactNode}> = ({s, children}) => (
  <Sequence from={s[0]} durationInFrames={s[1]}>
    <FadeScene dur={s[1]}>{children}</FadeScene>
  </Sequence>
);

export const Intro: React.FC = () => (
  <AbsoluteFill>
    <Background />

    <Scene s={S.salam}>
      <Words text="السلام عليكم ورحمة الله وبركاته" size={120} gap={7} />
    </Scene>
    <Scene s={S.welcome}>
      <Words text="أهلًا وسهلًا فيكم في ورشة" size={120} gap={6} highlight={{word: 'ورشة', color: COLORS.cyan}} />
    </Scene>
    <Scene s={S.title}>
      <Title />
    </Scene>
    <Scene s={S.presenter}>
      <Presenter />
    </Scene>
    <Scene s={S.goal1}>
      <Words text="هدفنا مو بس نتعلم أداة جديدة" size={115} gap={7} />
    </Scene>
    <Scene s={S.goal2}>
      <Goal />
    </Scene>
    <Scene s={S.motto}>
      {/* Imagine عند 21.05s، Build عند 21.96s، Animate عند 22.74s */}
      <Motto at={[632 - 590, 659 - 590, 682 - 590]} />
    </Scene>
    <Scene s={S.chat}>
      <Chat />
    </Scene>
    <Sequence from={S.start[0]}>
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
        <Start />
      </AbsoluteFill>
    </Sequence>

    {/* ───── الصوت ───── */}
    <Audio src={staticFile('voice/intro.mp3')} />
    <Audio
      src={staticFile('sfx/music.wav')}
      loop
      volume={(f) => interpolate(f, [0, 20, INTRO_DURATION - 40, INTRO_DURATION], [0, 0.14, 0.14, 0], clamp)}
    />
    {[S.presenter[0], S.goal1[0], S.motto[0], S.chat[0]].map((f) => (
      <Sequence key={f} from={f - 4} durationInFrames={25}>
        <Audio src={staticFile('sfx/whoosh.wav')} volume={0.25} />
      </Sequence>
    ))}
    <Sequence from={S.title[0] + 4}>
      <Audio src={staticFile('sfx/hit.wav')} volume={0.45} />
    </Sequence>
    <Sequence from={538} durationInFrames={10}>
      <Audio src={staticFile('sfx/pop.wav')} volume={0.4} />
    </Sequence>
    {[632, 659, 682].map((f) => (
      <Sequence key={f} from={f} durationInFrames={10}>
        <Audio src={staticFile('sfx/pop.wav')} volume={0.4} />
      </Sequence>
    ))}
    <Sequence from={S.start[0] + 2}>
      <Audio src={staticFile('sfx/hit.wav')} volume={0.6} />
    </Sequence>
  </AbsoluteFill>
);
