// الإعلان الترويجي للورشة — عمودي 1080×1920، 30 ثانية، بدون تعليق صوتي (تقدر تضيف صوتك)
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Background} from '../components/Background';
import {COLORS, FONT} from '../theme';

export const PROMO_DURATION = 900;
const T: React.FC<{size: number; color?: string; w?: number; style?: React.CSSProperties; children: React.ReactNode}> = ({size, color = '#fff', w = 900, style, children}) => (
  <div style={{fontFamily: FONT, fontSize: size, fontWeight: w, color, direction: 'rtl', textAlign: 'center', lineHeight: 1.25, position: 'relative', ...style}}>{children}</div>
);
const useSp = (d = 0, damping = 13) => { const f = useCurrentFrame(); const {fps} = useVideoConfig(); return spring({frame: f - d, fps, config: {damping}}); };

// 1) الهوك: لقطات سريعة من أعمال مصنوعة بالكود
const Hook: React.FC = () => {
  const f = useCurrentFrame();
  const shots = ['f1', 'f2', 'f3', 'f4', 'f5', 'f6'];
  const i = Math.min(shots.length - 1, Math.floor(f / 14));
  const p = useSp(78);
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
      <div style={{position: 'absolute', top: 360, width: 960, height: 540, borderRadius: 36, overflow: 'hidden', boxShadow: `0 40px 120px ${COLORS.pink}55`,
        transform: `scale(${1.04 - (f % 14) * 0.003}) rotate(${i % 2 ? 2 : -2}deg)`}}>
        <Img src={staticFile(`promo/${shots[i]}.jpg`)} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
      </div>
      <div style={{position: 'absolute', top: 1040, width: '100%', opacity: interpolate(f, [70, 82], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}), transform: `scale(${0.8 + p * 0.2})`}}>
        <T size={120}>كل هذا…</T>
        <T size={140} color={COLORS.yellow}>صُنع بالكود</T>
      </div>
    </AbsoluteFill>
  );
};

// 2) فكرة. برومبت. كود. فيديو.
const Steps: React.FC = () => {
  const words: [string, string][] = [['فكرة', COLORS.white], ['برومبت', COLORS.cyan], ['كود', COLORS.pink], ['فيديو', COLORS.yellow]];
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', gap: 30}}>
      {words.map(([w, c], k) => <Word key={w} text={w} color={c} delay={k * 18} last={k === 3} />)}
    </AbsoluteFill>
  );
};
const Word: React.FC<{text: string; color: string; delay: number; last: boolean}> = ({text, color, delay, last}) => {
  const p = useSp(delay, last ? 8 : 14);
  return <T size={last ? 220 : 170} color={color} style={{opacity: Math.min(1, p * 1.5), transform: `translateY(${(1 - p) * 80}px) scale(${0.7 + 0.3 * p})`}}>{text}.</T>;
};

// 3) كود Remotion يتحوّل لفيديو
const CODE = `const p = spring({frame, fps});\n\nreturn (\n  <h1 style={{\n    transform: \`scale(\${p})\`\n  }}>\n    CODE TO MOTION\n  </h1>\n);`;
const CodeToVideo: React.FC = () => {
  const f = useCurrentFrame();
  const chars = Math.floor(interpolate(f, [10, 80], [0, CODE.length], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}));
  const out = useSp(95, 9);
  return (
    <AbsoluteFill style={{alignItems: 'center', paddingTop: 230}}>
      <T size={84}>اصنع فيديوهاتك</T>
      <T size={84} color={COLORS.cyan}>بالكود مع <span dir="ltr">Remotion</span></T>
      <pre style={{marginTop: 60, width: 900, minHeight: 470, background: '#0b0620ee', border: `2px solid ${COLORS.violet}`, borderRadius: 30, padding: 40, boxSizing: 'border-box',
        color: '#e9e4ff', fontSize: 40, fontFamily: 'monospace', direction: 'ltr', textAlign: 'left', whiteSpace: 'pre-wrap', position: 'relative'}}>{CODE.slice(0, chars)}<span style={{opacity: f % 20 < 10 ? 1 : 0, color: COLORS.cyan}}>▌</span></pre>
      <div style={{marginTop: 40, width: 900, height: 300, borderRadius: 30, background: `linear-gradient(135deg, ${COLORS.violet}, ${COLORS.pink})`, display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', opacity: interpolate(f, [88, 96], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}}>
        <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 92, color: '#fff', transform: `scale(${out})`}}>CODE TO MOTION</div>
      </div>
    </AbsoluteFill>
  );
};

// 4) موقع الورشة: لقطات حقيقية داخل جوال
const Site: React.FC = () => {
  const f = useCurrentFrame();
  const shots = ['s-home', 's-library', 's-project', 's-workshops'];
  const i = Math.min(3, Math.floor(f / 45));
  const ph = useSp(0, 14);
  const chips = ['Skills', 'AI Agents', 'Prompts', 'Templates'];
  return (
    <AbsoluteFill style={{alignItems: 'center', paddingTop: 150}}>
      <T size={70}>وكل اللي تحتاجه بعد الورشة</T>
      <div style={{marginTop: 50, width: 560, height: 1100, borderRadius: 70, border: '14px solid #1f1640', overflow: 'hidden', background: '#000', position: 'relative',
        boxShadow: `0 40px 120px ${COLORS.cyan}44`, transform: `translateY(${(1 - ph) * 600}px)`}}>
        <Img src={staticFile(`promo/${shots[i]}.jpg`)} style={{width: '100%', position: 'absolute', top: 0, transform: `translateY(${-interpolate(f % 45, [5, 45], [0, 260], {extrapolateLeft: 'clamp'})}px)`}} />
      </div>
      <div style={{position: 'absolute', bottom: 150, display: 'flex', gap: 18, flexWrap: 'wrap', justifyContent: 'center', width: 980}}>
        {chips.map((c, k) => { const p = spring({frame: f - 20 - k * 10, fps: 30, config: {damping: 12}}); return (
          <div key={c} style={{fontFamily: FONT, fontWeight: 900, fontSize: 46, color: COLORS.bg, background: [COLORS.cyan, COLORS.pink, COLORS.yellow, '#fff'][k], borderRadius: 999, padding: '10px 34px', transform: `scale(${p})`}}>{c}</div>); })}
      </div>
    </AbsoluteFill>
  );
};

// 5) هوية الورشة + 6) الدعوة
const Reveal: React.FC = () => {
  const a = useSp(0, 10), b = useSp(18), c = useSp(32);
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', gap: 20}}>
      <Img src={staticFile('logo.png')} style={{width: 220, height: 220, borderRadius: 50, objectFit: 'cover', transform: `scale(${a})`}} />
      <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 150, color: '#fff', textAlign: 'center', lineHeight: 1.05, textShadow: `0 0 60px ${COLORS.pink}aa`, transform: `scale(${0.8 + a * 0.2})`, position: 'relative'}}>CODE<br />TO MOTION</div>
      <T size={58} w={700} color={COLORS.muted} style={{opacity: b}}>تقديم: عبدالرحمن مصطفى</T>
      <div style={{opacity: c, transform: `translateY(${(1 - c) * 40}px)`, marginTop: 30, position: 'relative'}}>
        <T size={76} color={COLORS.yellow}>السبت 28 نوفمبر</T>
        <T size={52} w={700}>6:00 – 8:30 مساءً بتوقيت السعودية</T>
      </div>
    </AbsoluteFill>
  );
};
const CTA: React.FC = () => {
  const f = useCurrentFrame();
  const a = useSp(0), b = useSp(22, 8), c = useSp(45, 10);
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', gap: 16}}>
      <T size={50} w={700} color={COLORS.cyan} style={{opacity: a}}>ورشة أونلاين · بث مباشر</T>
      <T size={96} style={{opacity: a}}>لا تكتفِ بمشاهدة المستقبل.</T>
      <T size={190} color={COLORS.yellow} style={{transform: `scale(${b})`}}>اصنعه.</T>
      <div style={{marginTop: 40, fontFamily: FONT, fontWeight: 900, fontSize: 80, color: COLORS.bg, background: '#fff', borderRadius: 999, padding: '18px 80px', position: 'relative',
        transform: `scale(${c * (1 + Math.sin(f / 6) * 0.02)})`}}>سجّل الآن</div>
      <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 52, color: '#fff', direction: 'ltr', marginTop: 20, opacity: c, position: 'relative'}}>lu.ma/34qf5z1h</div>
    </AbsoluteFill>
  );
};

const scenes: [number, number, React.FC][] = [[0, 120, Hook], [120, 150, Steps], [270, 180, CodeToVideo], [450, 180, Site], [630, 150, Reveal], [780, 120, CTA]];

export const Promo: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Background />
      {scenes.map(([from, dur, C]) => (
        <Sequence key={from} from={from} durationInFrames={dur}>
          <AbsoluteFill style={{opacity: interpolate(f, [from, from + 8, from + dur - 8, from + dur], [0, 1, 1, from + dur >= PROMO_DURATION ? 1 : 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}}><C /></AbsoluteFill>
        </Sequence>
      ))}
      {scenes.slice(1).map(([from]) => <Sequence key={'w' + from} from={from - 4}><Audio src={staticFile('sfx/whoosh.wav')} volume={0.45} /></Sequence>)}
      <Sequence from={630}><Audio src={staticFile('sfx/hit.wav')} volume={0.7} /></Sequence>
      <Sequence from={802}><Audio src={staticFile('sfx/pop.wav')} volume={0.6} /></Sequence>
      <Audio loop src={staticFile('sfx/music.wav')} volume={(fr) => interpolate(fr, [0, 20, 860, 900], [0, 0.3, 0.3, 0], {extrapolateRight: 'clamp'})} />
    </AbsoluteFill>
  );
};
