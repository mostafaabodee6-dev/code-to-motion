# ربط وكيلك بـ Remotion (بدل MCP)

خادم MCP الرسمي من Remotion **انقفل في 26 أكتوبر 2026**. البديل الرسمي Skills:

```bash
# داخل مجلد مشروع Remotion
npx remotion skills add
# تحديثها لاحقًا
npx remotion skills update
```
بعدها اطلب من وكيلك `/remotion-docs` لما يحتاج التوثيق المحدّث.
لو كنت مضيف `remotion-documentation` في إعدادات MCP عندك، احذفه.

## خوادم MCP اختيارية (Claude Code)
```bash
# توثيق محدّث لأي مكتبة
claude mcp add --transport http context7 https://mcp.context7.com/mcp
# تحكّم بالمتصفح وتصوير الصفحات
claude mcp add playwright npx @playwright/mcp@latest
# تعليق صوتي (يحتاج حساب ElevenLabs)
claude mcp add --transport http elevenlabs https://api.elevenlabs.io/v1/mcp
```
`mcp.example.json` نفس الإعدادات بصيغة JSON لأدوات ثانية (مثل Cursor).
⚠️ لا تحط أي مفتاح API داخل ملفات المشروع أو ترفعه على GitHub.
