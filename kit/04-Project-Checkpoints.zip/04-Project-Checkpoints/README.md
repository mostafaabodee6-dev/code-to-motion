# نقاط الاستعادة (Checkpoints)

لو تأخرت أو خرب مشروعك، خذ حل المرحلة اللي وقفت عندها:

| المجلد | الحل | وين تحطه |
|---|---|---|
| `01-first-animation` | `L01_FirstAnimation.tsx` | `src/lessons/` |
| `02-interpolate` | `L02_Interpolate.tsx` | `src/lessons/` |
| `03-spring` | `L03_Spring.tsx` | `src/lessons/` |
| `04-sequence` | `L04_Sequence.tsx` | `src/lessons/` |
| `05-transitions` | `L05_Transitions.tsx` | `src/lessons/` |
| `06-media` | `L06_Media.tsx` | `src/lessons/` |
| `07-final-project` | مجلد `final` | `src/final/` |

كل ملف يحتاج `src/theme.ts` و `src/components/` و `public/` من المشروع النهائي (`03-Final-Project`).
بعد ما تنسخه، سجّله في `src/Root.tsx` (شوف كيف مسجّل في المشروع النهائي).

قائمة التحقق لكل مرحلة: `CHECKPOINTS.md`
