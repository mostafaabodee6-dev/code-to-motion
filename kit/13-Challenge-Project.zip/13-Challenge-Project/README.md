# تحدي ما بعد الورشة: فيديو «عني»

1. افتح المشروع النهائي، وفي Studio اختار `AboutMe` (أو `T01-AboutMe`).
2. من لوحة Props: اسمك، وش تشتغل، 3 مهارات، ولونك.
3. صدّر: `npx remotion render AboutMe out/about-me.mp4`
4. انشره مع منشن **@mostafaabodee8**، أو ارفعه في «معرض الأعمال» في موقع الورشة:
   https://mostafaabodee6-dev.github.io/code-to-motion/#gallery

**مستوى أصعب:** أضف مشهد رابع فيه حساباتك، وانتقال slide بين المشاهد، ونسخة عمودية للريلز.
