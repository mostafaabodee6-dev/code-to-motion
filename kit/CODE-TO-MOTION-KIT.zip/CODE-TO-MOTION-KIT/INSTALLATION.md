# التثبيت

1. ثبّت **Node.js** نسخة LTS من https://nodejs.org
2. ثبّت **VS Code** من https://code.visualstudio.com
3. تأكد إن عندك **Google Chrome**.
4. افتح Terminal واكتب:
   ```bash
   node -v
   npm -v
   ```
   لازم يطلع رقم Node ‏18 أو أعلى.
5. (اختياري) ثبّت وكيل AI داخل VS Code مثل Codex عشان تستخدم البرومبتات.

> **Windows:** لو PowerShell منع الأوامر، استخدم `npm.cmd` و `npx.cmd`.
