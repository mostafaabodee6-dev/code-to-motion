# حل المشاكل الشائعة

| المشكلة | الحل |
|---|---|
| `node` أو `npm` غير معروف | ثبّت Node LTS، وسكّر الـ Terminal وافتحه من جديد |
| PowerShell: running scripts is disabled | استخدم `npm.cmd` و `npx.cmd`، أو Command Prompt |
| Port 3000 مستخدم | سكّر أي Studio شغّال، أو `npm run dev -- --port=3001` |
| العربي مقطّع أو بالمقلوب | حط `direction: 'rtl'` على النص، وتأكد إن خط Cairo محمّل |
| Version mismatch | كل مكتبات `@remotion/*` نفس النسخة. ثبّت بـ `npx remotion add` |
| شاشة سوداء في الآخر | المدة = مجموع المشاهد − مجموع الانتقالات |
| الصورة أو الصوت ما يظهر | الملف داخل `public`، والمسار في `staticFile()` بدون كلمة public |
| التصدير بطيء | صدّر جزء للتجربة: `--frames=0-90` |

ما زبطت؟ انسخ الخطأ كامل وأرسله للوكيل مع برومبت «فيه خطأ» من `MASTER-PROMPTS.md`.
