# 8 قوالب Remotion

| القالب | المقاس | المدة | Props |
|---|---|---|---|
| T01-AboutMe | 1920×1080 | 10 ث | name, role, skills, accent |
| T02-LogoReveal | 1920×1080 | 5 ث | logo, brand, tagline, bg, accent |
| T03-LowerThird | 1920×1080 شفاف | 6 ث | name, title, accent, showBackdrop |
| T04-AppPromo | 1920×1080 | 12 ث | appName, headline, screenshot, features, cta, accent |
| T05-SocialReel | 1080×1920 | 15 ث | hook, points, handle, accent |
| T06-Explainer | 1920×1080 | 20 ث | question, steps, summary, accent |
| T07-Countdown | 1920×1080 | seconds + 2 ث | title, seconds, endText, accent |
| T08-Stats | 1920×1080 | 10 ث | title, stats, source, accent |

**أسهل طريقة:** القوالب كلها مسجّلة وجاهزة داخل المشروع النهائي (`03-Final-Project`) في مجلد Templates داخل Studio.
افتح القالب، غيّر من لوحة Props، وصدّر:
```bash
npx remotion render T02-LogoReveal out/logo.mp4
```
**Lower Third بخلفية شفافة** (حط showBackdrop = false):
```bash
npx remotion render T03-LowerThird out/lower-third.mov --codec=prores --prores-profile=4444 --pixel-format=yuva444p10le --image-format=png
```
المعاينات في مجلد `previews` (بنصف الدقة).

الملفات هنا نسخة من `src/templates` لو تبي تنقلها لمشروع ثاني: تحتاج `src/theme.ts` و `src/components/` وتثبيت `@remotion/transitions` و `@remotion/zod-types`.
