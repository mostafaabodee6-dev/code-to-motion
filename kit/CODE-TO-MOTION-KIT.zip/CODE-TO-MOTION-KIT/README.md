# CODE TO MOTION · حزمة الورشة

ورشة اصنع موشن جرافيك بالكود مع Remotion · تقديم عبدالرحمن مصطفى
الموقع: https://mostafaabodee6-dev.github.io/code-to-motion/

## ابدأ هنا
1. `INSTALLATION.md`: ثبّت Node و VS Code
2. `01-Workshop-Guide`: الدليل الكامل PDF · و`CHEAT-SHEET.pdf` ورقة وحدة للمراجعة السريعة
3. `03-Final-Project`: فك الضغط وشغّل `npm install` ثم `npm run dev`

| المجلد | وش فيه |
|---|---|
| 01-Workshop-Guide | الدليل التعليمي PDF |
| 02-Starter-Project | طريقة إنشاء مشروع فاضي تبدأ منه |
| 03-Final-Project | المشروع الكامل: الدروس، المشروع النهائي، القوالب، شاشات البث |
| 04-Project-Checkpoints | حل كل مرحلة لو تأخرت |
| 05-Remotion-Templates | 8 قوالب + معاينات |
| 06-AI-Skills | 20 Skill لـ Claude Code و Codex و Cursor |
| 07-AI-Agents | 8 وكلاء = فريق إنتاج |
| 08-Prompt-Library | برومبتات الورشة + 20 برومبت احترافي |
| 09-Agent-Setup | ربط وكيلك بـ Remotion (Skills الرسمية بدل MCP) |
| 10-Sample-Assets | خطوط ومؤثرات صوتية مرخّصة |
| 11-Exercises | 8 تمارين |
| 12-Troubleshooting | حل المشاكل الشائعة |
| 13-Challenge-Project | تحدي فيديو «عني» |
| 14-Sample-Outputs | فيديوهات نموذجية |

⚠️ المشروع ما يحتاج أي مفاتيح API. لا تحط مفاتيحك في الملفات (`.env.example`).
