# تحريك النصوص · Kinetic Typography

نص يظهر كلمة كلمة بإيقاع، مع إبراز الكلمة المهمة.

**المتغيرات:** `{{TEXT}}` · `{{HIGHLIGHT_WORD}}` · `{{ACCENT}}` · `{{SECONDS}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices
**مثال:** TEXT = "الفكرة تصير فيديو لما تكتبها كود" · HIGHLIGHT_WORD = فيديو

```text
Create a Remotion composition "Kinetic" (1920x1080, 30fps, {{SECONDS}} seconds).
Text: "{{TEXT}}"
- Split into lines of max 6 words; show max 2 lines at a time.
- Each word enters with spring (damping 13): opacity 0→1, translateY 60→0, scale 0.7→1, 5 frames between words.
- The word "{{HIGHLIGHT_WORD}}" arrives last with damping 8, color {{ACCENT}}, and a scale punch 1→1.15→1.
- Old lines exit upward while the next line enters (6-frame overlap).
- If the text is Arabic: direction rtl, Cairo font from public/fonts, animate words not letters.
- Hold the final line 1.5 seconds. Typecheck and render a still of the last line.
```
