# إنفوجرافيك متحرك · Animated Infographics

أرقام تعد وأعمدة ورسوم بيانية متحركة من بياناتك.

**المتغيرات:** `{{TITLE}}` · `{{DATA}}` · `{{SOURCE}}` · `{{ACCENT}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices
**مثال:** DATA = زوار: 12500، مشتركين: 3400، رضا: 96%

```text
Turn this data into a 12-second animated infographic "Infographic" (1920x1080, 30fps):
Title: "{{TITLE}}"
Data: {{DATA}}
Source: {{SOURCE}}
- Title enters with spring, then each value counts up from 0 (interpolate + Easing.out(cubic), 45 frames, 12 frames stagger).
- Bars start at zero; compare lengths only if values share a unit. Accent {{ACCENT}}.
- End with one takeaway sentence and the source in small text.
Do not invent numbers: use only the data above.
```
