# مراجعة الجودة النهائية · Visual Quality Review

مراجعة كاملة قبل التصدير: هوامش، تباين، عربي، توقيت، صوت.

**المتغيرات:** `{{COMPOSITION}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices
**مثال:** COMPOSITION = FinalProject

```text
Review {{COMPOSITION}} before export. Do not change code.
Render stills at the start, middle and end of every scene and the final frame. Check: text inside 5% safe margins, no cut-off or overlap,
contrast, Arabic order and punctuation, logo sharpness, reading time (≥1s per 3 words), transitions not over text, final frame held ≥1.5s.
If there's audio, check peaks with ffmpeg volumedetect (max ≤ -1 dB).
Report: numbered list "frame · problem · file · fix" and a verdict: ready / needs fixes.
```
