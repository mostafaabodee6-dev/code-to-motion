# مولّد الستوري بورد · Storyboard Generator

يقسّم فكرتك لمشاهد بالفريمات قبل ما يكتب أي كود.

**المتغيرات:** `{{IDEA}}` · `{{DURATION}}` · `{{FORMAT}}` · `{{AUDIENCE}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** أي وكيل AI
**مثال:** IDEA = إعلان ورشة موشن بالكود · DURATION = 30 · FORMAT = 9:16

```text
Before writing any code, storyboard this video.
Idea: {{IDEA}} · Duration: {{DURATION}} seconds · Format: {{FORMAT}} · Audience: {{AUDIENCE}}
Output a markdown table: # | time (s) | frames (30fps) | purpose | visual | on-screen text (≤8 words) | motion | audio.
Totals must add up exactly. Then list 3 risks (too much text, pacing, unclear CTA) and how you avoid them.
Wait for my approval before building.
```
