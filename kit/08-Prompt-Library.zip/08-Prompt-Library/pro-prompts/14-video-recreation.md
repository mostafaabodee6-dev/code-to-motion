# إعادة تنفيذ أسلوب مرجعي · Video Recreation

يحلل أسلوب فيديو أنت تملك حقوقه أو مسموح تستخدمه، ويبني فيديو جديد بنفس الروح.

**المتغيرات:** `{{REFERENCE_DESCRIPTION}}` · `{{MY_CONTENT}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices + مرجع تملك حقه أو مسموح باستخدامه
**مثال:** REFERENCE_DESCRIPTION = فيديو قديم من قناتي بإيقاع سريع ونصوص كبيرة

```text
I have permission to use this reference as style inspiration: {{REFERENCE_DESCRIPTION}}.
1. Describe its style as rules: pacing (cuts per second), type style, color palette, motion types, transitions, sound cues.
2. Build a NEW video with my own content: {{MY_CONTENT}}, applying those rules.
Do not copy its exact text, logos, characters, footage or music. Original layout and assets only.
```
