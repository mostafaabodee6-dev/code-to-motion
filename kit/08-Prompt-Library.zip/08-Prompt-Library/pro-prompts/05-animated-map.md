# خريطة متحركة · Animated Maps

مسار يتحرك بين مدن على خريطة مع علامات وأسماء.

**المتغيرات:** `{{MAP_IMAGE}}` · `{{POINTS}}` · `{{ACCENT}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices + صورة خريطة (SVG أو PNG) داخل public
**مثال:** POINTS = الرياض (980,520)، جدة (720,610)، المدينة (760,470)

```text
Create a 10-second animated map "MapRoute" (1920x1080, 30fps) using public/{{MAP_IMAGE}} as the background map.
Points (name and x,y position in px on the image): {{POINTS}}
- Slow camera push-in on the map (scale 1 → 1.15).
- Each point: a pin drops with spring and its name appears next to it (Arabic RTL if Arabic).
- Draw a curved route between points in order with an SVG path revealed by evolvePath from @remotion/paths, color {{ACCENT}}, a glowing dot traveling along it.
- Finish with all points visible for 1.5 seconds.
```
