# مزامنة مع الصوت · Audio Synchronization

يقسّم التعليق الصوتي لجمل ويخلي كل مشهد يبدأ مع جملته.

**المتغيرات:** `{{VOICE_FILE}}` · `{{COMPOSITION}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices + ffmpeg مثبّت
**مثال:** VOICE_FILE = voice/intro.mp3 · COMPOSITION = Intro

```text
Sync the composition {{COMPOSITION}} to the voice-over public/{{VOICE_FILE}}.
1. Get the duration with ffprobe and detect pauses with: ffmpeg -i public/{{VOICE_FILE}} -af silencedetect=noise=-35dB:d=0.25 -f null -
2. Make a table: phrase # | start (s) | start frame (30fps) | which scene/text.
3. Start each scene/text 3 frames before its phrase; set durationInFrames = audio length + 30.
4. Add <Audio> for the voice, music under it at 0.15, and raise music to 0.3 in long pauses.
Show me the table before editing code.
```
