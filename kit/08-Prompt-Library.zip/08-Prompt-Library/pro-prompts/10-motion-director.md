# المخرج الفني · Motion Director

يحوّل فكرة عامة لرؤية إخراجية واضحة: إحساس، ألوان، خطوط، إيقاع.

**المتغيرات:** `{{IDEA}}` · `{{PLATFORM}}` · `{{BRAND_COLORS}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** أي وكيل AI (أفضل مع Skill motion-director)
**مثال:** IDEA = فيديو تعريفي لمنصة بطاقات رقمية · PLATFORM = Instagram

```text
Act as a motion director. My idea: {{IDEA}}. Platform: {{PLATFORM}}. Brand colors: {{BRAND_COLORS}}.
Write a direction brief (max 15 lines): goal, one-sentence message, mood (3 adjectives), palette with hex, fonts and weights,
motion language (entrance style with spring damping, exits, transition type and length), pacing (duration, scene count, climax).
Then give a scene table. Describe references in words; don't copy any specific existing video.
```
