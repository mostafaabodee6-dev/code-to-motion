# تحسين الحركة · Motion Enhancement

يخلي الحركة الروبوتية ناعمة واحترافية بدون ما يغيّر المحتوى.

**المتغيرات:** `{{FILE}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices
**مثال:** FILE = src/final/Scenes.tsx

```text
Improve the motion quality of {{FILE}} without changing texts, colors or total duration:
- Replace linear interpolations on entrances with spring() or Easing.out(cubic); add clamp everywhere.
- Add 3-6 frame staggers to elements that enter together.
- Give each scene one main movement; make secondary motions smaller.
- Add exits (fade/slide 10-15 frames) so nothing just disappears.
- Smooth scene changes with TransitionSeries (fade or slide, 12-15 frames) and recalculate durations.
List each change with frame numbers, then render stills before/after for scene 1.
```
