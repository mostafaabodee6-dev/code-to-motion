# تسريع الرندر · Render Optimization

يكتشف وش يبطّئ الرندر ويسرّعه.

**المتغيرات:** `{{COMPOSITION}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices
**مثال:** COMPOSITION = Intro

```text
My render of {{COMPOSITION}} is slow. Diagnose and speed it up:
1. Time one frame with npx remotion still at the busiest frame; run npx remotion benchmark if useful.
2. Find heavy layers (big blur filters, backdrop-filter, large box-shadows, oversized images, <Video> instead of <OffthreadVideo>, work recalculated every frame).
3. Fix them keeping the look as close as possible; precompute with useMemo.
4. Recommend --concurrency for my CPU and give me the final render command.
Report: before/after time per frame.
```
