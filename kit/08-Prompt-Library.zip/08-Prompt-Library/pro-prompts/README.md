# البرومبتات الاحترافية (20)

بدّل كل `{{VARIABLE}}` بقيمتك قبل ما ترسل البرومبت.

01. تحريك النصوص · Kinetic Typography
02. تحريك الشعار · Logo Animation
03. فيديو منتج رقمي · SaaS Product Video
04. إنفوجرافيك متحرك · Animated Infographics
05. خريطة متحركة · Animated Maps
06. إعلان منتج · Product Commercial
07. ريل / شورتس · Short-Form Content
08. تحويل البودكاست لفيديو · Podcast Visualizer
09. مولّد الستوري بورد · Storyboard Generator
10. المخرج الفني · Motion Director
11. من سكريبت إلى فيديو · Script to Video
12. مزامنة مع الصوت · Audio Synchronization
13. موشن عربي احترافي · Arabic Motion Graphics
14. إعادة تنفيذ أسلوب مرجعي · Video Recreation
15. تحسين الحركة · Motion Enhancement
16. فيديو لكل المقاسات · Responsive Video
17. تسريع الرندر · Render Optimization
18. مصلّح أخطاء Remotion · Remotion Debugger
19. مراجعة الجودة النهائية · Visual Quality Review
20. إنتاج فيديوهات بالجملة · Batch Video Generator
