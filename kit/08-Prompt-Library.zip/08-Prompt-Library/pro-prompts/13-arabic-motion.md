# موشن عربي احترافي · Arabic Motion Graphics

يضبط العربي في الفيديو: اتجاه، خطوط، إنجليزي داخل عربي، وحركة بالكلمات.

**المتغيرات:** `{{FILE}}` · `{{FONT}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices
**مثال:** FILE = src/intro/Intro.tsx · FONT = Cairo

```text
Review and fix all Arabic text in {{FILE}}:
- Containers with Arabic: direction 'rtl' and correct alignment.
- Load {{FONT}} locally with @remotion/fonts from public/fonts (no web fallback).
- Animate by words, never letters (letter splitting breaks Arabic joining).
- English words, code or handles inside Arabic: wrap in <span dir="ltr">.
- Line height ≥ 1.3, no letter-spacing on Arabic, consistent numerals.
Render a still of every scene that has Arabic and list what you changed.
```
