# تحريك الشعار · Logo Animation

مقدمة شعار 5 ثواني بانفجار دوائر ونطّة واسم.

**المتغيرات:** `{{LOGO_FILE}}` · `{{BRAND}}` · `{{TAGLINE}}` · `{{BG}}` · `{{ACCENT}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices + شعارك داخل public
**مثال:** BRAND = هويتك · TAGLINE = بطاقتك الرقمية

```text
Build a 5-second logo reveal "LogoReveal" (1920x1080, 30fps) using public/{{LOGO_FILE}}.
1. Frames 0-20: 3 rings in {{ACCENT}} expand from the center and fade.
2. Frame 18: logo springs in (damping 9) with a -90° → 0° rotation and a growing glow.
3. Frame 45: "{{BRAND}}" slides up under the logo; frame 62: "{{TAGLINE}}" fades in.
Background {{BG}} with a soft radial light behind the logo. Hit sound (public/sfx/hit.wav) at frame 14.
Make LOGO_FILE, BRAND, TAGLINE, BG, ACCENT props with a Zod schema (zColor for colors).
```
