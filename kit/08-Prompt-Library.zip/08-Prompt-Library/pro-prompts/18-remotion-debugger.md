# مصلّح أخطاء Remotion · Remotion Debugger

تلصق الخطأ، ويفهمه ويصلّحه ويتأكد.

**المتغيرات:** `{{ERROR}}` · `{{COMMAND}}` · `{{FILE}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices
**مثال:** COMMAND = npx remotion render FinalProject out/final.mp4

```text
This command failed: {{COMMAND}}
Error:
{{ERROR}}
Related file: {{FILE}}
1. Explain the cause in one simple line.
2. Fix the cause (check: version mismatch between remotion and @remotion/* packages, staticFile paths, durations vs transitions, missing clamp, fonts, Math.random/Date.now).
3. Verify with npx tsc --noEmit and the same command.
4. Tell me what you changed.
```
