# فيديو منتج رقمي · SaaS Product Video

فيديو 30 ثانية يعرض موقعك أو تطبيقك بلقطات شاشة حقيقية.

**المتغيرات:** `{{PRODUCT}}` · `{{PROBLEM}}` · `{{FEATURES}}` · `{{URL}}` · `{{SCREENSHOTS}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices + لقطات شاشة في public/screens
**مثال:** PRODUCT = هويتك · FEATURES = بطاقة رقمية، QR، إحصائيات

```text
Create a 30-second SaaS product video for "{{PRODUCT}}" (1920x1080, 30fps) using the screenshots in public/screens/ ({{SCREENSHOTS}}).
Storyboard first (table with frames), then build:
1. Hook (0-3s): the problem "{{PROBLEM}}" in bold kinetic text.
2. Reveal (3-7s): product name + laptop frame with the home screenshot sliding in.
3. Features (7-24s): for each of {{FEATURES}}: zoom into the related part of a screenshot, animated cursor click, short label (≤5 words).
4. CTA (24-30s): {{URL}} big, logo, hold 2 seconds.
TransitionSeries between sections (slide, 12 frames). Background music at 0.25 with whoosh on transitions.
```
