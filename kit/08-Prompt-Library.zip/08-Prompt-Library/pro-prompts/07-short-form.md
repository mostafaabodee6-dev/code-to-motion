# ريل / شورتس · Short-Form Content

فيديو عمودي 15 ثانية بهوك و3 نقاط وكابشن.

**المتغيرات:** `{{HOOK}}` · `{{POINTS}}` · `{{HANDLE}}` · `{{ACCENT}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices
**مثال:** HOOK = 3 أسرار للموشن الاحترافي · HANDLE = @mostafaabodee8

```text
Create a vertical 1080x1920 video "Reel" (30fps, 15 seconds).
- 0-3s hook: "{{HOOK}}" word by word, very big, last word in {{ACCENT}}.
- 3-12s: three points {{POINTS}}, each with a giant number (1/2/3) springing in and the text below.
- 12-15s: "تابعني" + {{HANDLE}} in a pill.
Keep text out of the top 220px and bottom 380px (platform UI). Make all texts props. End frame should visually match the first frame so it loops.
```
