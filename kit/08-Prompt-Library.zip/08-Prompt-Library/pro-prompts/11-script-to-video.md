# من سكريبت إلى فيديو · Script to Video

تلصق السكريبت، ويطلع فيديو كامل بمشاهد ونصوص وانتقالات.

**المتغيرات:** `{{SCRIPT}}` · `{{FORMAT}}` · `{{STYLE}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices
**مثال:** FORMAT = 1920x1080 · STYLE = bold and colorful

```text
Turn this script into a Remotion video.
Script:
{{SCRIPT}}
Format: {{FORMAT}} · Style: {{STYLE}}
1. Split it into scenes (one sentence or idea each), estimate 2.5 words per second, show me the scene table.
2. For each scene: short on-screen text (≤ 8 words, not the full sentence), one main motion, and a simple visual (shape, icon, number, or image from public/).
3. Build with TransitionSeries, colors from src/theme.ts, Arabic RTL if Arabic.
4. Typecheck and render one still per scene.
```
