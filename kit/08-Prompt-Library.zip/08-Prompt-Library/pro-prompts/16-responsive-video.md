# فيديو لكل المقاسات · Responsive Video

يحوّل فيديو أفقي لنسخة عمودية ومربعة بدون ما يقص أي شي.

**المتغيرات:** `{{COMPOSITION}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices
**مثال:** COMPOSITION = FinalProject

```text
Create vertical (1080x1920) and square (1080x1080) versions of {{COMPOSITION}}.
- Read width/height with useVideoConfig and make the layout adapt: stack horizontal rows vertically when height > width, scale type by Math.min(width, height).
- Keep text inside safe zones (9:16: top 220px, bottom 380px free).
- Register {{COMPOSITION}}-Vertical and {{COMPOSITION}}-Square in Root.tsx sharing the same component and props.
Render a still of the busiest frame in each size and fix any overflow.
```
