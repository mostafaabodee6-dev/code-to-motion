# إعلان منتج · Product Commercial

إعلان 15 ثانية سينمائي لمنتج بصورة واحدة أو أكثر.

**المتغيرات:** `{{PRODUCT}}` · `{{IMAGE}}` · `{{BENEFITS}}` · `{{PRICE_OR_CTA}}` · `{{MOOD}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices + صورة منتج بخلفية شفافة
**مثال:** PRODUCT = عطر · BENEFITS = ثبات، فخامة، هدية · MOOD = luxury

```text
Make a 15-second {{MOOD}} product commercial "ProductAd" (1920x1080, 30fps) for "{{PRODUCT}}" using public/{{IMAGE}}.
1. Dark scene, light sweep reveals the product (mask + gradient), slow rotation and float.
2. Three benefits {{BENEFITS}} appear one by one next to the product with thin lines pointing to it.
3. Product centered, scale up, name + "{{PRICE_OR_CTA}}".
Cinematic: vignette, soft rim light in the accent color, transitions with fade (20 frames). Music bed with a hit on the final reveal.
```
