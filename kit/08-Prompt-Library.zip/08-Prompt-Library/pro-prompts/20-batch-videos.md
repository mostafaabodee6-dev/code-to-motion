# إنتاج فيديوهات بالجملة · Batch Video Generator

قالب واحد + ملف بيانات = عشرات الفيديوهات بأسماء مختلفة.

**المتغيرات:** `{{TEMPLATE}}` · `{{DATA_FILE}}` · `{{NAME_FIELD}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices + قالب فيه Zod schema
**مثال:** TEMPLATE = T01-AboutMe · DATA_FILE = data/team.json · NAME_FIELD = slug

```text
Generate one video per row of {{DATA_FILE}} using the template composition {{TEMPLATE}}.
1. Check the template has a Zod schema; validate every row against it and log invalid rows.
2. Write scripts/batch.ts using @remotion/bundler (bundle once) and @remotion/renderer (selectComposition + renderMedia per row with inputProps).
3. Output to out/<{{NAME_FIELD}}>.mp4, skip files that already exist (resume).
4. Add an npm script "batch" and tell me how to run it.
```
