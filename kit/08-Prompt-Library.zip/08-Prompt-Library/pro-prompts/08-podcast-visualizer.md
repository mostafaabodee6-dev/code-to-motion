# تحويل البودكاست لفيديو · Podcast Visualizer

مقطع صوتي يتحول لفيديو فيه موجات صوت وكابشن وصورة الضيف.

**المتغيرات:** `{{AUDIO_FILE}}` · `{{TITLE}}` · `{{SPEAKER}}` · `{{COVER}}`
**الأدوات:** Claude Code · Codex · Cursor
**المتطلبات:** مشروع Remotion شغّال + Skill remotion-best-practices + ملف صوت داخل public
**مثال:** AUDIO_FILE = episode-clip.mp3 · TITLE = كيف تبدأ مشروعك

```text
Create an audiogram "Podcast" from public/{{AUDIO_FILE}} (1080x1080, 30fps, duration = audio length via calculateMetadata).
- Cover image public/{{COVER}} in a rounded square, title "{{TITLE}}", speaker "{{SPEAKER}}".
- Audio-reactive bars under the cover using useAudioData + visualizeAudio from @remotion/media-utils (smooth, 32 bars, mirrored).
- Word-by-word captions at the bottom (ask me for the transcript if you can't transcribe), current word highlighted.
- Progress bar at the very bottom.
```
