# 02 · interpolate: من رقم إلى رقم

**الهدف:** تتحكم في الظهور والتكبير والحركة بـ interpolate مع clamp و Easing.

**الأداة:** Codex / وكيل AI

**المتطلبات:** المرحلة 01.

## البرومبت

```text
Create `src/MyInterpolate.tsx` (4 seconds, 120 frames, 30fps):
- A rounded card in the center with the text "CODE TO MOTION".
- Use interpolate for: fade in (frames 0→20), scale 0.6→1 (frames 0→30) with Easing.out(Easing.cubic), and fade out (frames 100→120).
- Always use extrapolateLeft/Right: 'clamp'.
- Register it in Root.tsx as "MyInterpolate".
Add Arabic comments that explain what clamp and Easing do.
```

## النتيجة المتوقعة
كرت يدخل بنعومة ويكبر ثم يختفي في الآخر.

## تأكّد إن كل شي تمام
- [ ] ما فيه قفزة مفاجئة بعد فريم 30 (يعني clamp شغّال).
- [ ] الاختفاء يبدأ عند فريم 100.

## لو ما ضبط: برومبت الإصلاح

```text
In MyInterpolate.tsx the card [يكبر زيادة / يختفي بدري / يرجع يكبر]. 
I think clamp or the input range is wrong. Fix it and explain the fix in one line.
```
