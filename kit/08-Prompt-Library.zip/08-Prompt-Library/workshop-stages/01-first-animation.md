# 01 · أول حركة: useCurrentFrame

**الهدف:** تفهم إن الفيديو = فريمات، وتحرّك نص بالاعتماد على رقم الفريم.

**الأداة:** Codex أو أي وكيل AI داخل VS Code

**المتطلبات:** المرحلة 00 شغّالة.

## البرومبت

```text
In my Remotion project, create `src/MyFirst.tsx`:
- A 3-second composition (90 frames, 30fps, 1920x1080).
- Dark purple background (#14063F).
- Big Arabic white text "أهلًا بـ Remotion" centered, direction rtl, font Cairo.
- Use useCurrentFrame: opacity goes 0→1 over the first 30 frames, and the text slides down 60px into place.
- Show the current frame number in the bottom-left corner.
- Register it in Root.tsx with id "MyFirst".
Write simple comments in Arabic explaining each line.
```

## النتيجة المتوقعة
فيديو 3 ثواني، النص يظهر وينزل، ورقم الفريم يتغيّر.

## تأكّد إن كل شي تمام
- [ ] حرّك مؤشر الوقت في Studio: الشفافية تتغيّر.
- [ ] رقم الفريم يبدأ من 0.

## لو ما ضبط: برومبت الإصلاح

```text
The animation in MyFirst.tsx doesn't look right: [صف المشكلة: النص ما يظهر / يطلع بالمقلوب / ...].
Check the useCurrentFrame math and fix it. Keep the same design.
```
