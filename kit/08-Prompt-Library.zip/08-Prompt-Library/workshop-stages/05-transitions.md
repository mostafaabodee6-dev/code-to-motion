# 05 · الانتقالات: fade و slide و wipe

**الهدف:** تربط المشاهد بانتقالات احترافية من @remotion/transitions.

**الأداة:** Codex / وكيل AI

**المتطلبات:** المرحلة 04. ثبّت المكتبة: `npx remotion add @remotion/transitions`

## البرومبت

```text
Convert MyScenes.tsx to use <TransitionSeries> from @remotion/transitions:
- fade between scene 1 and 2, slide (from-right) between 2 and 3, wipe between 3 and a new scene 4 with the text "يلا نبدأ".
- Each transition 15-20 frames with springTiming or linearTiming.
- Calculate the new total duration correctly (scenes minus transitions) and update Root.tsx.
Show me the duration calculation in an Arabic comment.
```

## النتيجة المتوقعة
انتقالات ناعمة بين 4 مشاهد بدون شاشة سوداء.

## تأكّد إن كل شي تمام
- [ ] ما فيه فريمات فاضية في آخر الفيديو.
- [ ] المدة في Root = مجموع المشاهد − مجموع الانتقالات.

## لو ما ضبط: برومبت الإصلاح

```text
There's a black screen at the end of my TransitionSeries video / I get a duration error.
Recalculate durationInFrames (scenes minus transitions) and fix Root.tsx.
```
