# 03 · spring: حركة نطّاطة طبيعية

**الهدف:** تستخدم spring وتفهم تأثير damping.

**الأداة:** Codex / وكيل AI

**المتطلبات:** المرحلة 02.

## البرومبت

```text
Create `src/MySpring.tsx` (4 seconds, 30fps):
- Three circles (pink #FF2E9A, blue #2F6BFF, yellow #FFD84D) that pop in one after another using spring().
- Each circle starts 8 frames after the previous one.
- Circle 1 damping 8, circle 2 damping 14, circle 3 damping 200, and a small label under each with its damping value.
- Register as "MySpring".
Explain in Arabic comments what damping changes.
```

## النتيجة المتوقعة
3 دوائر تنط بأشكال مختلفة حسب damping.

## تأكّد إن كل شي تمام
- [ ] damping 8 ينط أكثر، و200 بدون نطّة.
- [ ] التأخير بين الدوائر واضح.

## لو ما ضبط: برومبت الإصلاح

```text
The springs in MySpring.tsx all look the same / start at the same time.
Fix the frame offset and damping per circle.
```
