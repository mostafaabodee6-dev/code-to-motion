# 04 · Sequence: تقسيم الفيديو لمشاهد

**الهدف:** تبني فيديو من أكثر من مشهد بالترتيب.

**الأداة:** Codex / وكيل AI

**المتطلبات:** المرحلة 03.

## البرومبت

```text
Create `src/MyScenes.tsx` (6 seconds, 180 frames):
- 3 scenes using <Sequence>: scene 1 (frames 0-60) Arabic text "فكرة", scene 2 (60-120) "كود", scene 3 (120-180) "حركة".
- Each scene has its own background color and its text springs in.
- Inside each scene useCurrentFrame must start from 0 (explain why in an Arabic comment).
- Register as "MyScenes".
```

## النتيجة المتوقعة
3 مشاهد ورا بعض بكلمات: فكرة، كود، حركة.

## تأكّد إن كل شي تمام
- [ ] كل مشهد يبدأ حركته من جديد.
- [ ] ما فيه مشهدين فوق بعض.

## لو ما ضبط: برومبت الإصلاح

```text
In MyScenes.tsx the scenes overlap / the animation doesn't restart in scene 2.
Check the `from` and `durationInFrames` values and fix them.
```
