# 00 · التجهيز وإنشاء المشروع

**الهدف:** تشغّل مشروع Remotion جديد وتفتح Remotion Studio في المتصفح.

**الأداة:** Node.js (نسخة LTS) + VS Code + Terminal

**المتطلبات:** Node.js مثبّت: اكتب `node -v` ويطلع رقم 18 أو أعلى.

## البرومبت

```text
I want to start a new Remotion project on my computer.
1. Tell me the exact terminal commands to create it with `npx create-video@latest` (blank template, TypeScript).
2. Then the commands to enter the folder, install, and open Remotion Studio.
3. Explain each command in one simple line.
My OS is: [Windows / Mac].
```

## النتيجة المتوقعة
مجلد مشروع جديد، و`npm run dev` يفتح Studio على http://localhost:3000.

## تأكّد إن كل شي تمام
- [ ] Studio يفتح في المتصفح بدون أخطاء.
- [ ] تشوف Composition واحدة على الأقل في القائمة اليسار.

## لو ما ضبط: برومبت الإصلاح

```text
I ran `[الأمر]` and got this error:
[الصق الخطأ كامل]
My OS is [Windows/Mac], Node version is [node -v].
Explain the cause in one line and give me the exact fix commands.
```
