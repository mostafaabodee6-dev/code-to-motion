# 06 · الصور والخط والصوت

**الهدف:** تضيف شعارك وخط Cairo ومؤثر صوتي من مجلد public.

**الأداة:** Codex / وكيل AI

**المتطلبات:** حط ملفاتك داخل مجلد `public` (مثلًا `logo.png` و `whoosh.wav`).

## البرومبت

```text
Create `src/MyMedia.tsx` (5 seconds):
- Show public/logo.png with <Img src={staticFile('logo.png')}> that springs in.
- Load the Cairo font from public/fonts using @remotion/fonts (works offline).
- Play public/whoosh.wav with <Audio> exactly when the logo appears (use <Sequence from={...}>).
- Arabic title under the logo.
- Register as "MyMedia".
```

## النتيجة المتوقعة
الشعار يظهر مع صوت، والخط عربي سليم.

## تأكّد إن كل شي تمام
- [ ] الخط Cairo مو خط افتراضي.
- [ ] الصوت متزامن مع ظهور الشعار.

## لو ما ضبط: برومبت الإصلاح

```text
My logo/font/audio doesn't load in MyMedia.tsx: [الصق الخطأ].
Check staticFile paths (they must be relative to public/) and fix.
```
