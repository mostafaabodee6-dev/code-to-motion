# MASTER PROMPTS · CODE TO MOTION

برومبتات عامة تنفعك في أي مرحلة. انسخها كما هي وعدّل اللي بين [ ].

## 1. البرومبت الأساسي (حطه أول رسالة للوكيل)

```text
You are helping me learn Remotion (React video framework) in a beginner workshop.
Rules:
- Use Remotion 4 APIs only: useCurrentFrame, useVideoConfig, interpolate, spring, Sequence, TransitionSeries, Img, Audio, staticFile.
- 1920x1080, 30fps unless I say otherwise.
- Arabic text must have direction: 'rtl' and use the Cairo font.
- Keep each file short and add simple Arabic comments.
- After writing code, tell me the composition id to open in Studio.
- Don't install new packages without asking me first.
```

## 2. اشرح لي الكود

```text
Explain this Remotion file line by line in simple Arabic, like I'm a designer not a programmer:
[الصق الكود]
```

## 3. غيّر الشكل بدون ما تخرب الحركة

```text
Change only the design of [اسم الملف]: colors to [الألوان], font size [الحجم], background [الوصف].
Don't change the timing or animation logic.
```

## 4. خلّ الحركة أنعم

```text
The animation in [اسم الملف] feels robotic. Make it smoother using spring() or Easing, keep the same duration.
```

## 5. حوّل الفيديو لعمودي (Reels / TikTok)

```text
Make a vertical 1080x1920 version of the composition [id] as a new composition [id]-Vertical.
Re-layout the elements so nothing is cut off.
```

## 6. فيه خطأ

```text
I got this error in Remotion:
[الصق الخطأ كامل]
The file is [اسم الملف]. Explain the cause in one line and fix it.
```

## 7. فيديو "عني" (التحدي)

```text
Create a 10-second "About me" video with props: name, role, 3 skills, accent color (Zod schema).
Scenes: name springs in → role → the 3 skills one by one → my handle [@حسابك].
Register as "AboutMe".
```

> ⚠️ لا تلصق أي مفتاح API أو كلمة مرور في الشات مع أي وكيل AI. Remotion ما يحتاج أي مفتاح.
