# 07 · المشروع النهائي: فيديو 12 ثانية

**الهدف:** تجمع كل اللي تعلمته في فيديو إعلاني قصير قابل للتعديل من لوحة Props.

**الأداة:** Codex / وكيل AI

**المتطلبات:** المراحل 01 إلى 06.

## البرومبت

```text
Build `src/final/` — a 12-second promo video (30fps, 1920x1080) for [اسم مشروعك]:
- 4 scenes with TransitionSeries: Hook → Problem → Solution → Title + call to action.
- All texts and the accent color come from props defined with a Zod schema (use zColor from @remotion/zod-types for the color), so I can edit them from the Props panel in Studio.
- Arabic RTL text with Cairo font, animated word by word with spring.
- Background: animated gradient blobs.
- Register as "FinalProject" with defaultProps in Arabic.
Keep files small and add Arabic comments.
```

## النتيجة المتوقعة
فيديو 12 ثانية، تقدر تغيّر نصوصه ولونه من Studio بدون كود.

## تأكّد إن كل شي تمام
- [ ] لوحة Props تظهر يمين Studio.
- [ ] تغيير النص يتغيّر مباشرة في المعاينة.

## لو ما ضبط: برومبت الإصلاح

```text
The Props panel doesn't show / I get a Zod error in FinalProject.
Check that `schema` and `defaultProps` are passed to <Composition> and the zod version matches @remotion/zod-types. Fix it.
```
