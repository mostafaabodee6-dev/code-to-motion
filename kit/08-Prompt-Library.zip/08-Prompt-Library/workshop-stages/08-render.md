# 08 · التصدير والنشر

**الهدف:** تطلّع فيديو MP4 جاهز للنشر.

**الأداة:** Terminal

**المتطلبات:** المشروع يشتغل في Studio بدون أخطاء.

## البرومبت

```text
Give me the exact commands to:
1. Render the composition "FinalProject" to out/final.mp4.
2. Render a vertical 1080x1920 version for Reels (explain what I need to change).
3. Render a single still frame as a thumbnail PNG.
Explain the flags --crf and --codec in one line each.
```

## النتيجة المتوقعة
ملف `out/final.mp4` يشتغل في أي مشغل.

## تأكّد إن كل شي تمام
- [ ] الفيديو فيه صوت (لو حطيت صوت).
- [ ] المدة صحيحة.

## لو ما ضبط: برومبت الإصلاح

```text
`npx remotion render` failed with: [الصق الخطأ].
Explain the cause simply and give me the fix.
```
