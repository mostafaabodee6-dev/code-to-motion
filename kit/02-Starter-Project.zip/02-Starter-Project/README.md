# مشروع البداية (فاضي)

عشان تبني بنفسك من الصفر مع البرومبتات:

```bash
npx create-video@latest
```
اختار **Blank** و **TypeScript**، وبعدها:
```bash
cd اسم-المشروع
npm run dev
```
ابدأ من `08-Prompt-Library/workshop-stages/01-first-animation.md`.

لو تبي تشوف الحل الجاهز لكل درس، افتح `03-Final-Project`.
