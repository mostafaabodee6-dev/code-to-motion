# 8 وكلاء (فريق إنتاج كامل)

| الأداة | انسخ | النتيجة |
|---|---|---|
| Claude Code | `claude-code/.claude` | `.claude/agents/*.md` |
| Cursor | `cursor/.cursor` | `.cursor/agents/*.md` |
| Codex | `codex/.agents` | كل وكيل كـ Skill اسمها `agent-…` تناديها بـ `$agent-production-manager` |

الوكلاء يستخدمون Skills من `06-AI-Skills`، فثبّتها معهم.

**جرّب:** «استخدم الوكيل production-manager وسوّ لي ريل 15 ثانية عن …»

| الوكيل | الدور | يستخدم |
|---|---|---|
| `creative-director` | المخرج الإبداعي | motion-director, color-director, brand-animation |
| `script-writer` | كاتب السكريبت | storyboard-artist, kinetic-typography |
| `motion-designer` | مصمم الحركة | kinetic-typography, cinematic-transitions, ui-animation, 3d-motion-design |
| `remotion-developer` | مبرمج الفيديو | remotion-expert, arabic-typography, asset-manager, motion-debugger |
| `sound-designer` | مصمم الصوت | audio-sync |
| `video-editor` | المونتير | video-editor, video-accessibility |
| `quality-inspector` | مراجع الجودة | visual-quality-control, video-accessibility |
| `production-manager` | مدير الإنتاج | storyboard-artist, render-optimizer, automated-video-pipeline |
