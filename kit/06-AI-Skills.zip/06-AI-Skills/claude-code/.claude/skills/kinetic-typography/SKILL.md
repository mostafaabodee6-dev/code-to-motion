---
name: kinetic-typography
description: "Kinetic typography: text that moves with rhythm — word-by-word reveals, emphasis words, scale punches, masks, and timing to voice or beat. Use for quote videos, hooks, titles and lyric-free text animations."
---

# Kinetic Typography

## Timing formula
- Words per second on screen: 2–3 for reading, 4–5 for energy.
- Stagger between words: 4–6 frames. Hold the full line ≥ 20 frames before it leaves.
- Emphasis word: arrives last or with a bigger spring (damping 8) and the accent color.

## Techniques (all frame-driven)
1. **Word pop**: per word `spring({frame: frame - start - i*gap})` → opacity + translateY + scale 0.7→1.
2. **Mask reveal**: wrapper with `overflow: hidden`, inner text translateY 100% → 0.
3. **Scale punch**: on the key word, scale 1 → 1.15 → 1 over 8 frames with interpolate.
4. **Line replace**: old line exits up (opacity 1→0, y 0→-40) while the new one enters from below, 6-frame overlap.
5. **Highlight sweep**: a colored bar behind the word with scaleX 0→1 (transformOrigin right for Arabic).
6. **Counter**: numbers via `Math.round(interpolate(...))` with tabular digits.

## Layout
- Max 2 lines on screen, max ~8 words per line in 16:9, ~4 in 9:16.
- Keep text inside a 5% safe margin; big type (100–160 px at 1080p).

## Sync to voice
Get phrase start times (see `audio-sync`), convert seconds → frames (`Math.round(sec * fps)`), and start each line at its phrase.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
