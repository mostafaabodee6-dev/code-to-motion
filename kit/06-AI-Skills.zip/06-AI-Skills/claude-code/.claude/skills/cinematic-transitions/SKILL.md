---
name: cinematic-transitions
description: "Cinematic scene transitions in Remotion: choosing and building fades, slides, wipes, zooms, whip-pans, light leaks and match cuts with correct timing math. Use when scenes need to connect smoothly or feel cinematic."
---

# Cinematic Transitions

## Ready-made (`@remotion/transitions`)
`fade()`, `slide({direction})`, `wipe({direction})`, `flip()`, `clockWipe({width, height})`, with `linearTiming({durationInFrames})` or `springTiming({config, durationInFrames})`.
Newer versions also ship more presentations (for example dissolve, cross-zoom, zoom-blur, push-cut, film-burn). Check `node_modules/@remotion/transitions` or the docs for what your version has before using one.
**Duration math:** total = sum of scene durations − sum of transition durations. Recalculate every time.

## Choosing
| Feeling | Transition | Length |
|---|---|---|
| Calm, elegant | fade / cross-dissolve | 15–25 f |
| Energy, next point | slide or whip | 8–15 f |
| Reveal / new chapter | wipe, clockWipe | 15–20 f |
| Continuity | match cut (same shape/color position in both scenes) | 0 f |

## Custom moves (frame-driven)
- **Zoom-through**: outgoing scale 1→3 + opacity→0, incoming scale 0.6→1.
- **Whip pan**: translateX ±120% with motion blur feel — add `filter: blur(px)` peaking mid-transition (keep ≤ 12px for render speed), or `@remotion/motion-blur`.
- **Light leak**: an absolutely positioned radial gradient with opacity peaking at the cut.

## Rules
- Use at most 2 transition types per video.
- Direction should follow reading direction (Arabic: content arrives from the left edge and moves right-to-left consistently).
- Never put a transition over text people still need to read.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
