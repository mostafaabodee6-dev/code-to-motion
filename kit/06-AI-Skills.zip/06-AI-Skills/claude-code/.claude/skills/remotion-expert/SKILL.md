---
name: remotion-expert
description: "Builds correct, production-quality Remotion compositions: Composition registration, Sequence/Series/TransitionSeries timing, spring and interpolate, props with Zod. Use for any request to create or change a Remotion video."
---

# Remotion Expert

## Building blocks
| Need | Use |
|---|---|
| Value over time | `interpolate(frame, [a, b], [x, y], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing})` |
| Natural entrance | `spring({frame: frame - delay, fps, config: {damping}})` (8 bouncy · 12 balanced · 200 no bounce) |
| Scenes in order | `<Series>` or `<Sequence from durationInFrames>` (frame restarts at 0 inside) |
| Transitions | `@remotion/transitions` `<TransitionSeries>`; total = Σ scenes − Σ transitions |
| Files in public/ | `staticFile('logo.png')` with `<Img>`, `<Audio>`, `<OffthreadVideo>` |
| Editable video | `schema` (Zod, `zColor()` from `@remotion/zod-types`) + `defaultProps` on `<Composition>` |
| Duration from props | `calculateMetadata` on `<Composition>` |

## Workflow
1. Plan scenes and frame ranges first; write them as a comment at the top of the file.
2. One component per scene; keep each file under ~150 lines.
3. Register in `src/Root.tsx` with id, fps, width, height, durationInFrames.
4. Install add-ons only with `npx remotion add <package>` so versions match.
5. Typecheck, render stills at every scene's middle frame, fix, then render.

## Common mistakes to avoid
- Forgetting clamp → values overshoot after the range.
- Absolutely positioned background covering normal-flow content: give content `position: 'relative'` or wrap it in `<AbsoluteFill>`.
- Mixing versions of `remotion` and `@remotion/*` packages.
- Using `Math.random()` — use `random('seed')` from remotion instead.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
