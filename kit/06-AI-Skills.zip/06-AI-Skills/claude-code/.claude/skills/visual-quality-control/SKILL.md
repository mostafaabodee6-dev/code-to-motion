---
name: visual-quality-control
description: "Visual QA before export: renders stills at key frames and checks safe margins, text overflow, contrast, RTL correctness, timing, audio levels and consistency. Use before any final render or delivery."
---

# Visual Quality Control

Do not change code in this pass; produce a report.

## Steps
1. List compositions and durations from `src/Root.tsx`.
2. Render stills: first frame, middle and last frame of every scene, and the final frame.
3. Check each still:
   - Text inside 5% safe margin (9:16: platform safe zones)
   - No cut-off, overlapping or orphan words; max 2 lines
   - Contrast readable; accent used sparingly
   - Arabic order and punctuation correct; English inside Arabic not flipped
   - Logo sharp (not upscaled), correct colors
4. Timing: reading time ≥ 1 s per 3 words; transitions not over text; final frame held ≥ 1.5 s.
5. Audio (if any): `ffmpeg -i out.mp4 -af volumedetect -f null -` → max_volume ≤ −1 dB; music under voice.

## Report format
Numbered list: `frame · problem · file · suggested fix`, then a verdict: ready / needs fixes.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
