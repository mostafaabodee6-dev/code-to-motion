---
name: color-director
description: "Color and light direction for motion graphics: palettes, contrast for readability, gradients, glows and consistent grading across scenes. Use when choosing colors or when a video looks flat or inconsistent."
---

# Color Director

## Palette rules
- 60/30/10: background / main / accent. Accent highlights one element per scene.
- Text contrast ≥ 4.5:1 against what's behind it (check light text on gradients at their lightest point).
- Dark backgrounds: not pure black — use a deep tinted color (e.g. #14063F).

## Depth & light
- Gradients: 2–3 soft radial blobs that drift slowly (`Math.sin(frame / 60)`).
- Glow: `boxShadow: 0 0 60px accent` or `textShadow` on key text only.
- Vignette: radial gradient to 30–40% dark at the edges to focus the center.

## Consistency
- Put all colors in `src/theme.ts`; scenes import them.
- Same grade over footage: a semi-transparent color overlay (`mixBlendMode: 'soft-light'`) applied to every clip.
- Check stills from every scene side by side before rendering.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
