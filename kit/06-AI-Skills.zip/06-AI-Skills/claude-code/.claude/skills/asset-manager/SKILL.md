---
name: asset-manager
description: "Organizes and loads video assets: public/ folder structure, staticFile, fonts with @remotion/fonts, image sizes, audio formats, licensing notes. Use when adding logos, images, fonts, music or footage to a Remotion project."
---

# Asset Manager

## Folder structure
```
public/
  brand/   logo.svg, logo.png
  fonts/   Cairo-400.ttf, Cairo-900.ttf
  images/  (sized to how big they appear)
  sfx/     whoosh.wav, pop.wav, hit.wav
  music/   bg.mp3
  clips/   footage .mp4
  LICENSES.md  (source + license of every third-party file)
```

## Loading
- Images/audio/video: `staticFile('brand/logo.png')` — path relative to public, no leading `public/`.
- Fonts: `loadFont({family, url: staticFile('fonts/Cairo-900.ttf'), weight: '900'})` once in `theme.ts`.
- Remote URLs work but local files render faster and never break.

## Rules
- File names: lowercase, dashes, no spaces or Arabic letters.
- Prefer SVG for logos; PNG with transparency otherwise.
- Only use assets you have rights to; record the license in `public/LICENSES.md`.
- Never put API keys or private files in `public/` — it is served as-is.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
