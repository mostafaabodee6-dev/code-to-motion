---
name: audio-sync
description: "Syncing motion to voice-over, music beats and sound effects: detecting phrase timings, converting seconds to frames, placing SFX, ducking music. Use when a video has narration or must hit beats."
---

# Audio Sync

## Voice-over → scene timings
1. Get the duration: `ffprobe -v error -show_entries format=duration -of csv=p=0 voice.mp3`.
2. Find pauses: `ffmpeg -i voice.mp3 -af silencedetect=noise=-35dB:d=0.25 -f null -` → read `silence_end` times = phrase starts.
3. Map each phrase to a scene; frame = `Math.round(seconds * fps)`. Start visuals 2–4 frames **before** the word.
4. Composition duration = voice duration + 1 s tail.

## Music & beats
- Mark beats by ear or with a BPM: beat frame = `round(i × 60 / bpm × fps)`.
- Cut or punch on beats; big moments on downbeats.
- Volume as a function: `volume={(f) => interpolate(f, [0, 20, end-30, end], [0, 0.3, 0.3, 0])}`.
- Duck music under voice (0.12–0.18) and raise it in pauses.

## SFX
`<Sequence from={frame}><Audio src={staticFile('sfx/whoosh.wav')} volume={0.5} /></Sequence>` — whoosh on transitions, pop on entrances, hit on the logo/CTA. Max one SFX per second.

## Audio-reactive visuals
`useAudioData` + `visualizeAudio` from `@remotion/media-utils` for bars/waves.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
