---
name: arabic-typography
description: "Correct, beautiful Arabic text in motion videos: RTL layout, font loading, mixed Arabic/English, numerals, punctuation and word-by-word animation without breaking letter joining. Use whenever on-screen text is Arabic."
---

# Arabic Typography for Video

## Must-do
- Container: `direction: 'rtl'`, `textAlign: 'right'` (or center). Flex rows: `flexDirection: 'row'` already flows right-to-left under rtl.
- Load fonts locally: `loadFont({family: 'Cairo', url: staticFile('fonts/Cairo-900.ttf'), weight: '900'})` from `@remotion/fonts`. Good free families: Cairo, Tajawal, IBM Plex Sans Arabic, Noto Kufi Arabic, Readex Pro, Amiri (serif).
- Animate **words, never letters**: splitting Arabic into characters breaks the joining. Split on spaces.
- Line height 1.3–1.5 (Arabic needs more than Latin); avoid letter-spacing on Arabic.
- English/code inside Arabic: wrap in `<span dir="ltr">` so it doesn't flip.
- Quotes: prefer «» or plain "" and test the render; parentheses mirror automatically.
- Numbers: decide once — Western (123) or Arabic-Indic (١٢٣) — and keep it consistent.

## Motion that suits Arabic
- Word reveal from the right (translateX positive → 0) or from below.
- Mask/wipe reveals going right → left.
- Kashida-free: never stretch words with tatweel for animation.

## Checklist before render
- [ ] No reversed words or punctuation at the wrong end
- [ ] Mixed English reads correctly
- [ ] Font is the intended one (not a fallback) — compare a still

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
