---
name: social-media-video
description: "Short vertical videos for Reels, Shorts and TikTok: 9:16 layout, hooks in the first second, safe zones for platform UI, captions and loops. Use for any 1080x1920 or short-form request."
---

# Social Media Video

## Format
1080×1920, 30fps, 7–30 s. Register a separate composition (e.g. `Reel`) rather than scaling a 16:9 one.

## Safe zones
Keep text out of the top 220 px and bottom 380 px (platform UI) and 60 px from the sides.

## Hook
First 1–1.5 s: the boldest line, big (100–140 px), moving. No logos first.

## Structure
Hook → 3 quick points (2–3 s each, big numbers 1/2/3) → CTA with handle. Captions always on (most people watch muted).

## Loop
End on a frame that visually matches the first one so replays feel seamless.

## Export
`npx remotion render Reel out/reel.mp4 --crf=18`. Keep file < 100 MB.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
