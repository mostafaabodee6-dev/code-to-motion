---
name: storyboard-artist
description: "Plans a video as a storyboard before building: scene list with duration in frames, on-screen text, visuals, motion and audio cues, plus quick still previews. Use at the start of any video longer than 10 seconds."
---

# Storyboard Artist

## Output format
A markdown table, one row per scene:
`# | time (s) | frames | purpose | visual | on-screen text | motion | audio`
Then totals: duration, frames, scene count.

## Structure templates
- **Promo (15–30 s)**: Hook → Problem → Solution → Proof/Features → CTA.
- **Explainer (30–90 s)**: Question → Why it matters → Steps (3) → Summary → CTA.
- **Social (9:16, 15 s)**: Hook in first 1.5 s → 3 fast points → handle/CTA.

## Rules
- Hook must work with sound off.
- One idea per scene; text ≤ 8 words.
- Frames are integers at the composition fps; durations add up exactly.

## Preview
After the table, build placeholder scenes (title text + color block) and render one still per scene so the user can approve the flow before detailed animation.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
