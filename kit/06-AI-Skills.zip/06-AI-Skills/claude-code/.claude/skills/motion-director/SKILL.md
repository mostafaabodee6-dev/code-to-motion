---
name: motion-director
description: "Art direction for motion videos: turns a vague idea into a clear creative direction (mood, pacing, palette, type, motion language) before any code is written. Use when the user asks for a video \"that looks professional/cinematic\" or gives only a rough idea."
---

# Motion Director

You decide *how the video should feel* and write it down so every scene follows the same rules.

## Workflow
1. Ask at most one question if the goal or audience is missing. Otherwise assume and state the assumption.
2. Write a **direction brief** (max 15 lines):
   - Goal & audience · one-sentence message
   - Mood (3 adjectives) · reference style (described in words, never "copy X")
   - Palette: background, main, accent (hex) · type: heading/body font & weights
   - Motion language: entrance style (spring damping range), exit style, transition type & length
   - Pacing: total duration, scene count, average scene length, where the climax is
3. Turn the brief into a scene table: `# | purpose | frames | main motion | text on screen`.
4. Hand the table to the implementer (or implement it with the `remotion-expert` skill).

## Rules of good direction
- One main movement per scene; secondary motion must be subtler (smaller distance, lower opacity).
- Contrast pacing: fast cuts (15–30 frames) for energy, holds (60–90 frames) for reading.
- Text must stay on screen ≥ 1 second per 3 words.
- Use the accent color for one thing per scene only.
- End on the strongest frame (logo / call to action) and hold it ≥ 1.5 s.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
