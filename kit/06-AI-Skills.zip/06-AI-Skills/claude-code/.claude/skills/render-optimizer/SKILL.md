---
name: render-optimizer
description: "Speeds up Remotion renders and previews: concurrency, scale, partial renders, heavy effects, video assets, caching and cloud rendering. Use when renders are slow, memory runs out, or the preview lags."
---

# Render Optimizer

## Quick wins
- Test with part of the video: `--frames=0-90`, and lower size: `--scale=0.5`.
- Concurrency: `--concurrency` ≤ CPU cores (try `npx remotion benchmark` to find the best value).
- Use `<OffthreadVideo>` for video files instead of `<Video>` when rendering.
- Heavy CSS (`filter: blur()` > 20px, big `box-shadow`, `backdrop-filter`) is slow — reduce or bake into images.
- Precompute expensive values outside the component or with `useMemo`; avoid large arrays rebuilt every frame.
- Large images: resize to the size you show them (a 6000px PNG at 400px is waste).

## Quality vs size
`--crf` 18 (high) … 28 (small). `--codec=h264` for sharing; ProRes for editing.

## Long or many videos
Render in parallel on servers with Remotion Lambda / Cloud Run, or split by `--frames` and concat with ffmpeg.

## Diagnose
Time a single frame with `npx remotion still`. If one frame takes > 1 s, find the heavy layer by commenting layers out.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
