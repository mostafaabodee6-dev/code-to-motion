---
name: 3d-motion-design
description: "3D elements in Remotion using @remotion/three (React Three Fiber): product spins, floating logos, 3D text and camera moves synced to frames. Use when the user asks for 3D in a Remotion video."
---

# 3D Motion Design

## Setup
`npx remotion add @remotion/three` then use `<ThreeCanvas width height>` from `@remotion/three` inside a composition. Inside it, regular React Three Fiber (`mesh`, lights, materials). Drive everything from `useCurrentFrame()` — do **not** use `useFrame` from R3F.

## Patterns
- **Turntable**: `rotation.y = interpolate(frame, [0, duration], [0, Math.PI * 2])`.
- **Float**: `position.y = Math.sin(frame / 20) * 0.1`.
- **Camera push-in**: animate camera z with spring; keep FOV constant.
- **Logo in 3D**: extrude an SVG shape (`ExtrudeGeometry`) or put the logo image on a plane with slight rotation.
- Lighting: one key light, one rim light in the accent color, soft ambient (0.3–0.5).

## Fake 3D without three.js (lighter, faster)
CSS `perspective` on the parent + `rotateX/rotateY/translateZ` on children; layered parallax (background moves less than foreground).

## Performance
- Keep polygon counts low; avoid real-time shadows unless needed.
- Render a short range first: `--frames=0-60`.
- Use `--gl=angle` (or the renderer's recommended GL option) if 3D renders black on the server.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
