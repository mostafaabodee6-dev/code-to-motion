---
name: video-editor
description: "Editing decisions inside Remotion: assembling clips with OffthreadVideo, trimming, pacing cuts, B-roll overlays, J/L cuts with audio, and color/caption consistency. Use when combining existing footage into a video."
---

# Video Editor (in code)

## Clips
- `<OffthreadVideo src={staticFile('clips/a.mp4')} trimBefore={30} trimAfter={150} />` inside a `<Sequence>` to trim and place.
- Keep source fps = composition fps when possible; otherwise accept frame mapping.
- Mute B-roll (`muted`) and keep one main audio track.

## Pacing
- Talking head: cut every 4–8 s with punch-in zoom (scale 1 → 1.12) to hide jump cuts.
- B-roll over voice for anything the speaker describes.
- J-cut: next scene's audio starts 6–10 frames before its picture; L-cut: audio continues after.

## Overlays
Lower thirds for names, captions for key phrases, progress bar for long videos.

## Final pass
- Audio peaks ≤ −1 dBFS, voice consistent; music ducked.
- No black frames between sequences (check `from` + `durationInFrames`).

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
