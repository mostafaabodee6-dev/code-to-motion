---
name: ui-animation
description: "UI and product-screen animation: app/website screenshots in device frames, cursor clicks, scrolling pages, UI elements popping in. Use for SaaS demos, app promos and feature highlights."
---

# UI Animation

## Building blocks
- **Device frame**: rounded rect with border + `<Img>` of the screenshot (`objectFit: 'cover'`). Phone ~380×780 at 1080p, laptop ~1200×750.
- **Scroll**: tall screenshot inside a fixed frame, `translateY = interpolate(frame, [a, b], [0, -(imgH - frameH)])` with `Easing.inOut`.
- **Cursor**: an SVG arrow moving between points with spring; click = scale 1→0.85→1 + ripple circle.
- **Zoom to feature**: scale the whole screen around the target (`transformOrigin` at the element) 1→1.8.
- **UI pop**: rebuild key elements (buttons, cards) as real components so they can spring in on top of the screenshot.

## Getting screenshots
Take them at 2× device scale (e.g. Playwright `deviceScaleFactor: 2`) as PNG/JPEG into `public/screens/`. Hide personal data before capturing.

## Pacing
One feature per 3–4 seconds: show → zoom → label → return. Labels short (≤ 5 words) in brand accent.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
