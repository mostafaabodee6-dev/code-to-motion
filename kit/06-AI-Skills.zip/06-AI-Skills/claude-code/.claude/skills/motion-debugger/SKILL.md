---
name: motion-debugger
description: "Finds and fixes Remotion errors: TypeScript errors, version mismatches, missing staticFile assets, wrong durations, black frames, fonts not loading, flicker and non-deterministic renders. Use when something fails or looks wrong."
---

# Motion Debugger

## Procedure
1. Reproduce: get the exact error text and the command that produced it.
2. Classify, then fix the cause (not the symptom):

| Symptom | Likely cause | Fix |
|---|---|---|
| "Version mismatch" | `remotion` and `@remotion/*` differ | Align versions; install with `npx remotion add` |
| Asset 404 | path includes `public/` or wrong case | `staticFile('logo.png')` relative to public |
| Black frames at the end | duration > sum of scenes (or transitions not subtracted) | Recalculate `durationInFrames` |
| Element jumps after an animation | missing clamp | `extrapolateRight: 'clamp'` |
| Font differs in render | font not awaited/loaded | `@remotion/fonts` `loadFont` with local file |
| Flicker / different each render | `Math.random`, `Date.now`, CSS animation | `random(seed)`, frame-based values |
| Content hidden behind background | positioned background over normal-flow content | `position: 'relative'` on content |
| Arabic reversed | missing `direction: 'rtl'` | set on the container |

3. Verify: `npx tsc --noEmit`, a still at the failing frame, then the render command.
4. Report: cause in one line, the change, how you verified.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
