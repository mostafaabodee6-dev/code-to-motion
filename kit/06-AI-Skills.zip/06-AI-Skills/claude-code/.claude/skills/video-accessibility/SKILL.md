---
name: video-accessibility
description: "Accessible videos: burned-in captions synced to speech, readable text sizes, contrast, reduced flashing, and transcript/subtitle files. Use when a video has speech or must be watchable without sound."
---

# Video Accessibility

## Captions
- Use `@remotion/captions` caption format (`text`, `startMs`, `endMs`). Get timings from a transcription tool (e.g. Whisper via `@remotion/install-whisper-cpp` or `@remotion/openai-whisper`) or from a provided transcript.
- Group into pages of 3–7 words (`createTikTokStyleCaptions`), highlight the current word.
- Style: bottom center above the safe zone, ≥ 48 px at 1080p, white on a dark pill or strong shadow.
- Also export an `.srt` for platforms.

## Readability
Min text size 36 px (1080p), contrast ≥ 4.5:1, ≥ 1 s per 3 words.

## Safety
No more than 3 flashes per second; avoid full-screen red flashes.

## Language
Arabic captions: RTL container, no letter splitting; numbers consistent.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
