---
name: data-visualization
description: "Animated infographics and charts in Remotion: counting numbers, bar/line/donut charts, maps-like progress, with honest scales. Use when the user wants statistics, reports or numbers turned into video."
---

# Data Visualization in Motion

## Honesty first
- Bars start at zero. Compare lengths only when values share a unit.
- Show the source on screen if the numbers are real; never invent data — ask for it or label it "example".

## Recipes
- **Count-up**: `Math.round(interpolate(frame, [s, s+45], [0, value], {clamp, easing: Easing.out(Easing.cubic)}))`, `toLocaleString('en-US')`, tabular figures.
- **Bars**: height = maxH × value/max × progress; stagger 10–15 frames.
- **Line chart**: build an SVG path from points; reveal with `evolvePath(progress, d)` from `@remotion/paths` (strokeDasharray/offset).
- **Donut**: SVG circle with `strokeDasharray = C`, `strokeDashoffset = C × (1 − share × progress)`.
- **Highlight**: dim other elements to 30% opacity when talking about one.

## Layout
Title top, chart center, one takeaway sentence at the end (the "so what"). Max 4 bars / 5 points on screen in 16:9.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
