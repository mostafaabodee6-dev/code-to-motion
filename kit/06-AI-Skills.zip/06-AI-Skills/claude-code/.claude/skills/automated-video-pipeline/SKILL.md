---
name: automated-video-pipeline
description: "Automates video production: data-driven templates, batch rendering many videos from JSON/CSV with props, file naming, and server-side rendering with @remotion/renderer. Use when the user needs many videos from one template."
---

# Automated Video Pipeline

## 1. Make the template
Composition with a Zod `schema` and `defaultProps`; every variable thing is a prop. Use `calculateMetadata` if duration depends on data.

## 2. Single render with props
`npx remotion render Promo out/ahmed.mp4 --props=./data/ahmed.json`

## 3. Batch from data (Node script)
```ts
import {bundle} from '@remotion/bundler';
import {renderMedia, selectComposition} from '@remotion/renderer';
import rows from './data/rows.json';

const serveUrl = await bundle({entryPoint: './src/index.ts'});
for (const row of rows) {
  const composition = await selectComposition({serveUrl, id: 'Promo', inputProps: row});
  await renderMedia({composition, serveUrl, codec: 'h264', outputLocation: `out/${row.slug}.mp4`, inputProps: row});
}
```
(Install with `npx remotion add @remotion/bundler @remotion/renderer`.)

## 4. Pipeline hygiene
- Validate each row against the schema before rendering; skip and log bad rows.
- Deterministic file names (`slug`), resume by skipping files that exist.
- Many videos: Remotion Lambda / Cloud Run.

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
