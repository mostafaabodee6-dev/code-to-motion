---
name: brand-animation
description: "Animating a brand identity: logo reveals, brand intros/outros, consistent motion rules from brand colors and fonts. Use when the user gives a logo or brand guide and wants intros, outros, stingers or a motion kit."
---

# Brand Animation

## Inputs to collect
Logo file (SVG preferred, else transparent PNG in `public/`), brand colors (hex), fonts, tagline, tone (serious / friendly / bold).

## Motion identity (write this first)
- Signature move: one repeatable motion (e.g., spring scale with damping 10 + 20° rotation) used in every brand video.
- Timing: intro 3–5 s, outro 4–6 s, stinger ≤ 1.5 s.
- Easing personality: corporate → `Easing.inOut(Easing.cubic)`; playful → spring damping 8–10; luxury → slow fades 30+ frames.

## Logo reveal recipes
1. **Burst**: expanding rings in accent color → logo springs in → name below.
2. **Draw-on** (SVG): `evolvePath` from `@remotion/paths` animates strokes, then fill fades in.
3. **Mask wipe**: logo revealed by a moving rectangle mask.
4. **Assemble**: logo parts (separate SVG paths) fly in from different directions with staggered springs.

## Deliverables
Make every brand video a template: props for logo, colors, tagline (Zod schema). Export intro/outro as MP4, and stingers with alpha (`--codec=prores --prores-profile=4444` or WebM VP8/VP9 with transparent background).

## Project conventions (apply unless the user says otherwise)
- Remotion 4, React, TypeScript. 1920x1080 at 30fps by default.
- Shared colors and fonts live in `src/theme.ts`; reuse them instead of hard-coding.
- Arabic text: `direction: 'rtl'`, Cairo (or the project font) loaded locally with `@remotion/fonts`.
- Every animation is a function of `useCurrentFrame()`. Never use CSS animations, `setTimeout` or `Date.now()`; they don't render deterministically.
- After changes run `npx tsc --noEmit`, then render a still per scene (`npx remotion still <Id> out/s.png --frame=<n>`) and look at it.
