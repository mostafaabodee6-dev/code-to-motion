# 20 Skill من CODE TO MOTION

بصيغة Agent Skills المفتوحة (مجلد فيه SKILL.md).

| الأداة | انسخ | للمشروع | لكل مشاريعك |
|---|---|---|---|
| Claude Code | `claude-code/.claude` | `.claude/skills/` | `~/.claude/skills/` |
| Codex | `codex/.agents` | `.agents/skills/` | `~/.agents/skills/` |
| Cursor | `cursor/.cursor` | `.cursor/skills/` | `~/.cursor/skills/` |

ثبّت نسخة وحدة بس لكل مشروع (Cursor يقرأ كمان مجلدات Claude و Codex، فلو نسخت أكثر من وحدة تتكرر). وبعدين أعد تشغيل الأداة.

ثبّت كمان Skills الرسمية من Remotion داخل مشروعك: `npx remotion skills add`

| Skill | وش تسوي |
|---|---|
| `motion-director` | المخرج الفني |
| `remotion-expert` | خبير Remotion |
| `arabic-typography` | الخطوط العربية |
| `kinetic-typography` | تحريك النصوص |
| `cinematic-transitions` | الانتقالات السينمائية |
| `3d-motion-design` | الموشن ثلاثي الأبعاد |
| `brand-animation` | تحريك الهوية |
| `ui-animation` | تحريك الواجهات |
| `data-visualization` | البيانات المتحركة |
| `audio-sync` | مزامنة الصوت |
| `storyboard-artist` | الستوري بورد |
| `video-editor` | المونتاج |
| `color-director` | الألوان والإضاءة |
| `social-media-video` | فيديوهات السوشال |
| `render-optimizer` | تسريع الرندر |
| `motion-debugger` | إصلاح الأخطاء |
| `visual-quality-control` | مراجعة الجودة |
| `video-accessibility` | الترجمة والوضوح |
| `asset-manager` | إدارة الأصول |
| `automated-video-pipeline` | أتمتة الإنتاج |
